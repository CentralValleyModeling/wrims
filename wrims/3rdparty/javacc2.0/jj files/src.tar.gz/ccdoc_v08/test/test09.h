/**
 * Root documentation.
 * @pkgdoc @root
 */
/**
 * Test package documentation.
 * @pkgdoc test
 */
/**
 * Documentation for class A.
 * @author Foo
 * @version 1.0
 */
class A {
public:
  //@{ a_mthod //@}
  int a_method();
};
/**
 * Documentation for class B.
 * @author Foo
 * @version 1.0
 */
class B {
public:
  int b_method();
  /**
   * b_method.
   * @suffix
   */
};
/**
 * Documentation for class C.
 * @author Foo
 * @version 1.0
 */
class C : public A, virtual protected B
{
public:
  int c_method();
};
/**
 * Documentation for class D.
 * @author Foo
 * @version 1.0
 */
class D : public C, public A
{
public:
  int d_method();
};
