// Issue 0075
/**
 * This comment s/b for fct33.
 */
typedef void fct33( int arg33 );

