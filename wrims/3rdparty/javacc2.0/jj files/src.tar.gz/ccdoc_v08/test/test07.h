// ================================================================
// Check alternative forms of the package hierarchy specification
// for @pkgdoc.
// ================================================================

//@{
// @pkgdoc A.B.C
//@}
int test09_1;

//@{
// @pkgdoc A::B::C
//@}
int test09_2;

//@{
// This form is NOT recommended!
// @pkgdoc A::B.C
//@}
int test09_3;

// Test the detection of illegal conditions.
namespace A {
  //@{ @pkg XX::YY::ZZ //@}
  int test09_4;
}

// Test a legal @pkg directive.
//@{ @pkg XX::YY::ZZ //@}
int test09_5;
