/**
 * -cdsm test.
 */
class test11 {
};
