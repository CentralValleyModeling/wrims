// Verify fix for issue 0083.
namespace test43 {
  /** No args */
  void fct();
  /** Int arg */
  void fct(int);
  /** Cstring arg */
  void fct(const char*);

  class Test {
  public:
    /**
     * This function references
     * @link test43::fct
     * to handle stuff.
     */
    void fct1();
  }
}
