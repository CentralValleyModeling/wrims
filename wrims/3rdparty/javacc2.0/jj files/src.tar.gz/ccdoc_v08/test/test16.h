// Verify issue 0033
/**
 * This is a function, not a struct.
 */
void test0016(struct test0016_struct* var);
