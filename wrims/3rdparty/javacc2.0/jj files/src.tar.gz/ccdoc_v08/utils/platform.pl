#!c:/Perl/bin/perl -w
#
# $Id: platform.pl,v 1.3 2001/10/26 02:55:50 Administrator Exp $
#
# This tool creates a directory tree.
#
# Usage: perl dtree.pl <directory>
#
use strict;
use Config;
&Main;

# ================================================
# MAIN
# ================================================
sub Main {
  while ( $#ARGV >= 0 ) {
    my $arg = shift @ARGV;
    if ( $arg eq "-version" ) {
      my $X = "\$";
      print "\$Id: platform.pl,v 1.3 2001/10/26 02:55:50 Administrator Exp $X\n";
      exit 0;
    }
    elsif ( $arg eq "-h" || $arg eq "-help" ) {
      &Help;
      exit 0;
    }
    else {
      print STDERR "ERROR: Unrecognized switch.\n";
      print STDERR "       Use the -h switch to get more information.\n";
      print STDERR "\n";
      exit 1;
    }
  }
  my $osn = $Config{'osname'};
  my $osv = $Config{'osvers'};
  $osv = "$1$2" if ($osv =~ /(.*)\(.*\)(.*)/);  # issue 0079: bzoe 10/18/01
  print "$osn-$osv\n";
}
# ================================================
# Help
# ================================================
sub Help {
  my $X = "\$";
  print <<END

\$Id: platform.pl,v 1.3 2001/10/26 02:55:50 Administrator Exp $X

usage: perl platform.pl [-h] [-help] [-version]

  -h
  -help     On-line help.

  -version  Print the program version and exit.

examples\:

  prompt> perl platform.pl
  MSWin32

END
}
