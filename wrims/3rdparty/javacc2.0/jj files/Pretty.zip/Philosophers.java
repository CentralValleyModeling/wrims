import  java.util.Date;
import  java.util.Random;




/**
* <img src="images/dining.gif" border=0 align=left>
* Another entertaining class to provoke <a
* href="http://www.inet.alsutton.com/psion-java/mailing-list/">Psion-Java
* discussion</a> about <em>Palava</em>'s implemention of Java multi-threading.
* As well as running simultaneous "philosopher" threads, these philosophers
* now also have to cooperate -- synchronize -- on Java heap objects. In this
* case, <tt>Chopstick</tt>s.
* <p>
* The running program, started from the command prompt, is purely text
* based: it just talks to <tt>System.out</tt>.  This makes it much easier
* to study the logic of the problem without being sidetracked by other issues.
* If you want to see <tt>Philosophers</tt> running just download the
* <a href="Philosophers.java">sourcecode</a> and compile it
* on your system.
* <p>
* Have you ever seen Java at the assembler level?  Take a wander around the
* <a href="http://kimera.cs.washington.edu/verifier.html">Kimera Class Verifier</a>'s
* <a href="Philosophers.jsm">disassembly of Philosophers.class</a>.
* <p>
* <a href="http://www.dnai.com/~bfalk/dining.html">The Dining Philosophers Problem</a>
* was originally dreamt up in 1965 by Edsger W. Dijkstra to demonstrate the full
* horror of deadlock gremlins that can bedevil concurrent systems after midnight.
* <p>
* An emergent property of these five dining philosophers is that only two
* philosophers can be eating at any given time (obviously not neighbours
* of eachother).
* <p>
* I'm actually not sure if this implementation has cracked the "Dining
* Philosophers" problem here, there's probably deadlock lurking somewhere.  But
* that's not the point.  The point is:  how is this thread stuff going to be
* implemented by the design of the <em>Palava</em> DYL?
* <p>
* You may want to compare this "cooperating threads" situation with the
* much simpler but absolutely fundmental
* <a href="HelloWorlds.html">HelloWorlds</a> example.
* <p>
* @version              1.00 alm Sat 5-Jul-97
* <p>
* @author               <a HREF="mailto:sandy@almide.demon.co.uk">Sandy Anderson</a>
* <p>
* Last change:  ALM   5 Jul 97    3:30 am
* <p>
**/
public class Philosophers
    implements Runnable
{

    private static final int MIN_PAUSE_MILLIS =  5000;
    private static final int MAX_PAUSE_MILLIS =  10000;
    private static final char BELL =  '\007';
    /** This philosopher's left chopstick is his lefthand neighbour's right chopstick **/
    public Chopstick leftChopstick =  new Chopstick();
    /** This philosopher's right chopstick is his righthand neighbour's left chopstick **/
    public Chopstick rightChopstick; // will refer to righthand neighbour's leftChopstick
    /** The name of this great philosopher **/
    protected String name;
    private Random dice =  new Random();
    private Thread engine;


    /** Construct a <tt>Philosophers</tt> instance with a name. **/
    public Philosophers (String name) {
        this.name =  name;
        this.dice.setSeed((new Date()).getTime() + this.hashCode());

        // IF TESTING
        if (this.name == name)  this.name = name;
        if (this.name == name)
          this.name = name;
        if (this.name == name) { this.name = name; }
        if (this.name == name) { this.name = name;
        } 
        if (this.name == name) { this.name = name; this.name = name;
        }
        if (this.name == name) {
          this.name = name;
          this.name = name;
          this.name = name;
        }
        if (this.name == name)
        {
          this.name = name;
          this.name = name;
          this.name = name;
        }

        // FOR TESTING
        for (int i = 0; i < 10; i++)
          this.name = name;

        // WHILE TESTING
        while (i < 10) 
          this.name = name;
    }


    /** This philosopher is told his right chopstick. **/
    public void setRight (Philosophers righthandNeighbour) {
        this.rightChopstick =  righthandNeighbour.leftChopstick;
    }


    /**
    * Starts this <tt>Philosophers</tt> Runnable instance.
    *
    * <p>
    * @see                     Philosophers#run()
    **/
    public void wakes () {
        engine =  new Thread(this, name);
        engine.start();
    }


    /**
    * A dining philosopher is either thinking deep thoughts or getting hungry and eating.
    *
    * <p>
    * @see                     Philosophers#think()
    * @see                     Philosophers#eat()
    **/
    public void run () {
        if (rightChopstick == null) System.exit(1); // in case of design boo-boo

        while (true) {
            think();
            eat();
        }
    }


    /** A method of great thought. **/
    protected void think () {
        System.out.println(name + " thinks");
        killSomeTime();
    }


    /**
    * Eating means first waiting to own both a left and right chopstick.
    *
    * <p>
    * When finished eating, the philosopher burps.  This is to aid digestion,
    * and is also conducive to further deep thinking.  The burps are simulated
    * by sending ASCII bel to the console, and makes a run of the mutually
    * cooperating Dining Philosophers threads altogether more entertaining to
    * watch.
    * <p>
    * @see                     Philosophers#obtainChopsticks()
    * @see                     Philosophers#dropChopsticks()
    **/
    /*
    protected void eat () {
        System.out.println(name +         " ?    ?");

        synchronized (rightChopstick) {
            System.out.println(name +     " ?    !");

            synchronized (leftChopstick) {
                killSomeTime(              "!EATS!");
                System.out.println(name + " .ahhh!");
            }
            System.out.println(name +     " *burp*" + BELL);
        }
    }
    */
    protected void eat () {
        obtainChopsticks();
        System.out.println(name + " !EATS!");
        killSomeTime();
        dropChopsticks();
        System.out.println(name + " *burp*" + BELL);
    }


    /**
    * Called by <tt>eat()</tt>.
    *
    * <p>
    * This is the one tricky method of the Dining Philosophers
    * problem.
    * <p>
    * This is no laughing matter.  On my first attempt at this I fell into the
    * classic trap: holding on to one chopstick while waiting for the other.
    * Running the philosophers at speed (no delays) for 15 minutes eventually
    * brought sudden deadlock.  They had all at the same time, got ownership
    * of a right chopstick, and were all now waiting for their left...
    * <p>
    * <center><img src="images/dining.gif" border=0></center>
    * <p>
    * <em>...deadlock!</em>
    * <p>
    * So don't hold on to a chopstick if you can't get the other:  put the
    * chopstick down again with a nudge, and wait for someone to nudgify you
    * when something changes again.
    * <p>
    * This is one hell of a good exercise in parallel thinking:  It's got a lot of
    * similarities to recursive thinking.  If you want to start really understanding
    * multi-threading in Java, <b>do this exercise!</b> And it's certainly given
    * me a feel for what kind of things must and must not be happening at the
    * implementation level.
    * <p>
    * This is because when you hit deadlock, rather like a <em>Stack
    * Overflow</em> in recursion, you're forced to kind of run up against the
    * machine level, conceptually.  Your abstract Java code and the damned Virtual
    * Machine kind of meet eye to eye, and glare at eachother, snorting.  Anyway,
    * Edsger Dijkstra's "Dining Philosophers" problem is one of those
    * <em>superb</em> questions that has no one cut and dried solution, and
    * makes you keep thinking and thinking, way beyond the subject.
    * <p>
    * In plain English, this class is nowhere near the "best" solution.
    * <p>
    * @see                     Philosophers#eat()
    * @see                     Philosophers#dropChopsticks()
    **/
    protected void obtainChopsticks () {
        while (true) {
            boolean r =  leftChopstick.ownedBy(this);
            boolean l =  rightChopstick.ownedBy(this);
            if (l && r) break;

            if (l) {
                System.out.println(name + " !     ");
            } else if (r) {
                System.out.println(name + "      !");
            } else {
                System.out.println(name + " hungry");
            }

            // the randomness is not vital, but probably improves
            // "behaviour" of the system, by decoupling things.
            if (dice.nextInt()%2 == 0) {
                leftChopstick.dropFor(this);
                rightChopstick.dropFor(this);
            } else {
                rightChopstick.dropFor(this);
                leftChopstick.dropFor(this);
            }

            if (dice.nextInt()%2 == 0) {
                leftChopstick.grabFor(this);
                rightChopstick.grabFor(this);
            } else {
                rightChopstick.grabFor(this);
                leftChopstick.grabFor(this);
            }
        }
    }


    /**
    * Called by <tt>eat()</tt>.
    *
    * <p>
    * @see                     Philosophers#eat()
    * @see                     Philosophers#obtainChopsticks()
    **/
    protected void dropChopsticks () {
        if (dice.nextInt()%2 == 0) {
            leftChopstick.dropFor(this);
            System.out.println(name + " .ahhh!");
            rightChopstick.dropFor(this);
        } else {
            rightChopstick.dropFor(this);
            System.out.println(name + " !ahhh.");
            leftChopstick.dropFor(this);
        }
    }


    private 
    /*synchronized*/
    void killSomeTime () {
        int diff =  MAX_PAUSE_MILLIS - MIN_PAUSE_MILLIS;
        pause(Math.abs(dice.nextInt())%diff + MIN_PAUSE_MILLIS);
    }


    static private void pause (long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            System.out.println("InterruptedException: " + e);
        }
    }


    /**
    * STATIC main method:  What runs when you say "<tt>java Philosophers</tt>".
    *
    * <p>
    * This creates 5 <tt>Philosophers</tt>, Al, Dan, Matt, Sandy and Trevor.
    * They each have a leftChopstick sticking out their left breast pocket.
    * <p>
    * <tt>main</tt> links them up so that they form a ring, as around a table.
    * They are actually linked, one neighbour to another, only by their references
    * to eachother's chopsticks.
    * <p>
    * Finally, already connected in a ring, each is woken up to life as a Dining
    * Philosopher.
    * <p>
    * You can browse the <tt>Philosophers</tt>
    * <a href="Philosophers.java">sourcecode</a> and
    * <a href="Philosophers.jsm">disassembly</a>.
    * <p>
    * @see                     HelloWorlds#main(String[])
    **/
    static public void main (String[] args) {
        Philosophers Al, Dan, Matt, Sandy, Trevor;
        Al =  new Philosophers("Al");
        Dan =  new Philosophers("             Dan");
        Matt =  new Philosophers("                          Matt");
        Sandy =  new Philosophers("                                       Sandy");
        Trevor =  new Philosophers("                                                    Trevor");
        Al.setRight(Dan);
        Dan.setRight(Matt);
        Matt.setRight(Sandy);
        Sandy.setRight(Trevor);
        Trevor.setRight(Al);
        Al.wakes();
        Dan.wakes();
        Matt.wakes();
        Sandy.wakes();
        Trevor.wakes();
    }

}




/**
* A chopstick resource to be shared between two philosophers.
*
* <p>
* Either one philosopher has got hold of it or the other one has, or neither
* have:  definitely <em>never</em> both at once!
* <p>
* You can browse the <tt>Chopstick</tt>
* <a href="Chopstick.java">sourcecode</a> and
* <a href="Chopstick.jsm">disassembly</a>.
* <p>
* @version              1.00 alm Jul 4-Jul-97
* <p>
* @author               <a HREF="mailto:sandy@almide.demon.co.uk">Sandy Anderson</a>
* <p>
* Last change:  ALM   5 Jul 97    3:12 am
**/
class Chopstick {

    /** The owner can be null, or one of two philosophers. **/
    protected Philosophers owner =  null;


    /** Returns true if the chopstick is owned by phil, false otherwise. **/
    public synchronized boolean ownedBy (Philosophers phil) {
        return  phil.equals(owner);
    }


    /**
    * Attempts to get ownership for phil.
    *
    * <p>
    * If the current owner is null or phil already, this just returns true.
    * <p>
    * Otherwise the method waits for notification on this chopstick.
    * <p>
    * @see                  Chopstick#dropFor(Philosophers)
    **/
    public synchronized boolean grabFor (Philosophers phil) {
        if (owner == null || phil.equals(owner)) {
            this.owner =  phil;
            return  true;
        } else {
            try {
                wait();
            } catch (InterruptedException e) {
                System.out.println("Ooh, er. Interrupted Exception.");
            }

            return  false;
        }
    }


    /**
    * Drops phil's ownership.
    *
    * <p>
    * If the current owner is phil, this sets the owner to null and notifies
    * any thread waiting on this chopstick.
    * <p>
    * Otherwise the method has no effect.
    * <p>
    * @see                  Chopstick#grabFor(Philosophers)
    **/
    public synchronized void dropFor (Philosophers phil) {
        if (phil.equals(owner)) {
            this.owner =  null;
            notify();
        }
    }

}




/*  Correct my address in any reply, or it'll be treated as spam:
--                                                          
//     Alexander Anderson    <DELETE_THIS.sandy@almide.demon.co.uk>
//     Home Fone                               +44 (0) 171-794-4543
//     London, UK                    http://www.almide.demon.co.uk/ 
//     PGP print   C6 8C 55 F2 77 7B 99 9B  14 77 66 F5 B8 74 CF 12
*/

