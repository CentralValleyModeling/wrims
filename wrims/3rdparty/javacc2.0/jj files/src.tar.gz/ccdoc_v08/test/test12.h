/**
 * -nocdsm test.
 */
class test12 {
};
