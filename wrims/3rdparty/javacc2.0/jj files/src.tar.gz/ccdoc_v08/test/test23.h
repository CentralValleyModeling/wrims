// Test for issue 0048
namespace ccdoc_test23 {
  class class_one {
  };
  class class_two : public class_one {
  };
  class class_three : public ccdoc_test::class_one {
  };
}
