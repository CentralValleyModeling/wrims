import java.io.PrintWriter;
import java.util.*;

public class SimpleNode implements Node {
  protected Node parent = null;
  protected Node[] children;
  protected int id;
  protected VBParser parser;

  public SimpleNode(int i) {
    id = i;
  }

  public SimpleNode(VBParser p, int i) {
    this(i);
    parser = p;
  }

  public void jjtOpen() {
  }

  public void jjtClose() {
  }

  public void jjtSetParent(Node n) { parent = n; }
  public Node jjtGetParent() { return parent; }

  public void jjtAddChild(Node n, int i) {
    if (children == null) {
      children = new Node[i + 1];
    } else if (i >= children.length) {
      Node c[] = new Node[i + 1];
      System.arraycopy(children, 0, c, 0, children.length);
      children = c;
    }
    children[i] = n;
  }

  public Node jjtGetChild(int i) {
    return children[i];
  }

  public int jjtGetNumChildren() {
    return (children == null) ? 0 : children.length;
  }

  /** Accept the visitor. **/
  public Object jjtAccept(VBParserVisitor visitor, Object data) {
    return visitor.visit(this, data);
  }

  /** Accept the visitor. **/
  public Object childrenAccept(VBParserVisitor visitor, Object data) {
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        children[i].jjtAccept(visitor, data);
      }
    }
    return data;
  }


	/**
	**	Insert a new child into the list, shifting other elements down.
	**	This is different from jjtAddChild which would overwrite any current child).
	**	These routines can be used to modify the AST after it has been produced, e.g.
	**	to add statements to the end of a procedure etc. The new child[ren] must have
	**	corresponding "Token(s)" created for them which will be written out to any
	**	output file. This method will take care of linking these new tokens into the
	**	token chain.
	**
	**	NB: insertBefore == -1 implies insert at end.
	*/
	public void insertChild(SimpleNode newChild, int insertBefore) throws ParseException
	{
		insertChild(newChild, insertBefore);
	}

	public void insertChild(SimpleNode newChild, int insertBefore, String tokenText) throws ParseException
	{
		if (tokenText != null)
		{
			newChild.begin = Token.newToken(0);
			newChild.begin.image = tokenText;
			newChild.end = newChild.begin;
		}

		SimpleNode c[] = new SimpleNode[1];
		c[0] = newChild;
		insertChild(c, insertBefore);
	}

	public void insertChild(SimpleNode[] newChildren, int insertBefore) throws ParseException
	{
		if (children == null)
		{
			children = new Node[0];
		}

		if (newChildren[0].begin == null || newChildren[newChildren.length-1].end == null)
		{
			throw new ParseException("No token text for new child");
		}

		if (insertBefore < 0)
			insertBefore = children.length;

		Node c[] = new Node[children.length + newChildren.length];
		if (insertBefore > 0)
			System.arraycopy(children, 0, c, 0, insertBefore);
		System.arraycopy(newChildren, 0, c, insertBefore, newChildren.length);
		if (insertBefore < children.length)
			System.arraycopy(children, insertBefore, c, insertBefore + newChildren.length, children.length - insertBefore);
		children = c;

		/*
		**	That has set up the new JJTree node(s). We now have to link the tokens
		**	into the correct place, as follows:
		**		Find the first token that is to FOLLOW the new token(s).
		**		Update the "next" property of the new token to be this following token.
		**		Change the* token which currently points to the "following" token to
		**		point to the new token
		*/

		Token following = findFollowing(this, insertBefore + newChildren.length - 1);

		// Now follow the token chain, updaing the correct item.

		Token t;

		// Find the root node of the tree.
		Node node = this;
		while (node.jjtGetParent() != null)
		{
			node = node.jjtGetParent();
		}

		for (t = ((SimpleNode)node).begin; t != null; t = t.next)
		{
			if (t.next == following)
			{
				t.next = newChildren[0].begin;
				newChildren[newChildren.length - 1].end.next = following;
				break;
			}
		}
	}

	private Token findFollowing(SimpleNode node, int index)
	{
		System.out.println("Search node " + VBParserTreeConstants.jjtNodeName[node.id] + " at index " + index);
		for (int i = index + 1; i < node.jjtGetNumChildren(); i++)
		{
			if (((SimpleNode)node.jjtGetChild(i)).begin != null)
				return ((SimpleNode)node.jjtGetChild(i)).begin;
		}

		// Insert at end of this node (or end of the parent of this node...)

		while (node.end == null)
		{
			if (node.jjtGetParent() == null)
				return null;

			node = (SimpleNode)(node.jjtGetParent());
		}

		return node.end.next;
	}

/*
	private Token findFollowing(SimpleNode node, int index)
	{
		System.out.println("Search node " + VBParserTreeConstants.jjtNodeName[node.id] + " at index " + index);
		for (int i = index + 1; i < node.jjtGetNumChildren(); i++)
		{
			if (((SimpleNode)node.jjtGetChild(i)).begin != null)
				return ((SimpleNode)node.jjtGetChild(i)).begin;
		}

		// Try parent (recursively).

		SimpleNode p = (SimpleNode)(node.jjtGetParent());

		if (p == null)
		{
			// Top-level node.

			return null;
		}

		// What index in the parent's child collection is this node?

		int myIndex = 0;
		for (myIndex = 0; myIndex < p.jjtGetNumChildren(); myIndex++)
		{
			if (p.jjtGetChild(myIndex) == node)
			{
				break;
			}
		}

		return findFollowing(p, myIndex);
	}
*/



  /* You can override these two methods in subclasses of SimpleNode to
     customize the way the node appears when the tree is dumped.  If
     your output uses more than one line you should override
     toString(String), otherwise overriding toString() is probably all
     you need to do. */

  public String toString()
  {
	  StringBuffer buff = new StringBuffer();

	  if (begin != null)
	  {
		buff.append(Integer.toString(begin.beginLine));
		buff.append(" ");
	  }

	  buff.append(VBParserTreeConstants.jjtNodeName[id]);
	  buff.append(":  ");
	  if (begin != null)
	  {
	  	buff.append(begin.image);
	  	if (begin.next != null && begin != end) buff.append("...");
      }

	  return buff.toString();
  }

  public String toString(String prefix) { return prefix + toString(); }

  /* Override this method if you want to customize how the node dumps
     out its children. */

  public void dump(String prefix) {
    System.out.println(toString(prefix));
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
	SimpleNode n = (SimpleNode)children[i];
	if (n != null) {
	  n.dump(prefix + "    ");
	}
      }
    }
  }

	static public String getTokenText(Token t)
	{
		return getTokenText(t, false);
	}

	static public String getTokenText(Token t, boolean includeSpecialText)
	{
		Token tt = t.specialToken;

		if (!includeSpecialText || tt == null)
			return t.image;

		StringBuffer buff = new StringBuffer();

		// Find the start of the special token chain.
		while (tt.specialToken != null)
			tt = tt.specialToken;
		// Now follow the chain forwards, collecting text
		while (tt != null)
		{
			buff.append(tt.image);
			tt = tt.next;
		}

		buff.append(t.image);

		return buff.toString();
	}

	private static final String spaces = "                                                           ";

	public String allText() throws ParseException
	{
		return allText(false);
	}

	public String allText(boolean includeSpecialText) throws ParseException
	{
		Token t = begin;
		StringBuffer buff = new StringBuffer();

		while (t != null)
		{
			buff.append(getTokenText(t, includeSpecialText));

			if (t == end)
				break;

			t = t.next;
		}

		return buff.toString();
	}

/*
	public String allText(boolean includeSpecialText, int depth) throws ParseException
	{
//		System.out.println(spaces.substring(0, depth*2) +
//			VBParserTreeConstants.jjtNodeName[id] +
//			" " + begin.sequence + " <" + begin.image + "> " + end.sequence + " <" + end.image);

		Token t = begin;
		StringBuffer buff = new StringBuffer();
		int childIndex = 0;

		while (t != null)
		{
			if (children != null && childIndex < children.length)
			{
				SimpleNode child = (SimpleNode)(children[childIndex]);

				// No tokens for this child?

				if (child.begin == null)
				{
					for ( ; childIndex < children.length; childIndex++)
					{
						SimpleNode next = (SimpleNode)(children[childIndex]);
						if (next.begin != child.begin)
							break;
					}

					continue;
				}

				// Have we reached the start of this child's tokens?

				if (child.begin == t)
				{
//					System.out.println(spaces.substring(0, depth*2) + "Call child");
					buff.append(child.allText(includeSpecialText, depth + 1));

					if (child.end == end)
					{
						return buff.toString();
					}

					t = child.end.next;

//					System.out.println(spaces.substring(0, depth*2) + "END of child");

					for ( ; childIndex < children.length; childIndex++)
					{
						SimpleNode next = (SimpleNode)(children[childIndex]);
						if (next.begin != child.begin)
							break;
					}

//					System.out.println(spaces.substring(0, depth*2) + "Next Child " + childIndex);
					if (childIndex < children.length)
					{
						child = (SimpleNode)(children[childIndex]);
//						System.out.println(spaces.substring(0, depth*2) + "           " +
//							VBParserTreeConstants.jjtNodeName[child.id] +
//							" " + child.begin.sequence + " <" + child.begin.image + "> " + child.end.sequence + " <" + child.end.image);
					}
					else
					{
//						System.out.println(spaces.substring(0, depth*2) + "           " + "No more children");
					}

					continue;
				}
			}

			buff.append(getTokenText(t, includeSpecialText));
//			System.out.println(spaces.substring(0, depth*2) + "Appended <" + getTokenText(t, false) + ">");

			if (t == end)
			{
//				System.out.println(spaces.substring(0, depth*2) + "END of this node at " + t.sequence + " " + t.image);
				break;
			}

			t = t.next;
		}

//		System.out.println(spaces.substring(0, depth*2) + "return " + VBParserTreeConstants.jjtNodeName[id] + ": <" + buff.toString() + ">");
		return buff.toString();
	}
*/

	public SimpleNode[] findNodes(int nodeId)
	{
		Vector nodes = new Vector(20);

		findNodes(nodeId, nodes);

		return (SimpleNode[])(nodes.toArray());
	}

	public SimpleNode findNode(int nodeId)
	{
		return findNode(nodeId, null);
	}

	public SimpleNode findNode(int nodeId, String name)
	{
		SimpleNode ret;

		if ((nodeId == id) && (name == null || name.equalsIgnoreCase(this.name)))
			return this;

		if (children == null)
			return null;

		for (int i = 0; i < children.length; i++)
		{
			SimpleNode n = (SimpleNode)(children[i]);
			ret = n.findNode(nodeId, name);

			if (ret != null)
				return ret;
		}

		return null;
	}

	protected void findNodes(int nodeId, Vector nodes)
	{
		if (id == nodeId)
			nodes.add(this);

		if (children == null)
			return;

		for (int i = 0; i < children.length; i++)
		{
			SimpleNode n = (SimpleNode)(children[i]);
			n.findNodes(nodeId, nodes);
		}
	}




  protected Token begin, end;

  public void setFirstToken(Token t) { begin = t;}
  public void setLastToken(Token t) { end = t;}

  public Token getFirstToken() { return begin;}
  public Token getLastToken() { return end;}

  public ParseException parseException = null;

  private String name;
  public String getName()
  {
	  return name;
  }
  public void setName(String name)
  {
	  this.name = name;
  }

  public void process(PrintWriter ostr)
  {
  }

  protected void print(Token t, PrintWriter ostr)
  {
	  Token tt = t.specialToken;

	  if (tt != null)
	  {
		  while (tt.specialToken != null) tt = tt.specialToken;

		  while (tt != null) {
			  ostr.print(tt.image);
			  tt = tt.next;
		  }
	  }

	  ostr.print(t.image);
  }
}

