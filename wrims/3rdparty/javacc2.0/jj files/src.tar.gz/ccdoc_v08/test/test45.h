// Verify the fix for issue 95.
namespace test45 {
  /**
   * Returns bug?
   * @returns Are extra
   * comma's inserted
   * at each
   * new line?
   */
  void Test();
}

