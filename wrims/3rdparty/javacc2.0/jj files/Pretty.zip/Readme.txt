Dear Java Programmer,



Contents
--------

    1   What have I downloaded?

    2   Running the Pretty-printer

    3   Test out the Pretty-printer

    4   Adding the Pretty-printer to your CLASSPATH



1   What have I downloaded?
---------------------------

Pretty (1.0.1 ALPHA Tue 23-Mar-99) is a Java source code formatter
(also called a Pretty-printer):  It makes Java source-code look neat
and readable.  It is especially useful for people beginning
programming with Java.
   
This version is not complete but is still useful.

It does not handle comments perfectly.  Nothing will be lost, but
comment layout may look rough.  Also, inner classes used in
allocation expressions ('new') can upset the layout.  Heavily nested
structured statements (like 'if', 'while', 'do', 'for') that contain
singleton statements (ie. they're not blocks) can also produce wierd
looking code that marches off to the right.  Similarly, array
initializers ('{1, 2, 3, 4}') will march off to the right.

At present, the Pretty-printer will only work on STANDARD JAVA
source-code.  It will NOT work with Java extensions, like Pizza.



2   Running the Pretty-printer
--------------------------------

Pretty.jar should be used as the program to run Pretty.  To run
Pretty, just type the following:

    java UK.co.demon.almide.util.pretty.Pretty

You will, of course, need to add the Pretty.jar file to your CLASSPATH
before the above command will work.

Pretty now has several options and has the following usage parameters:

Usage:  "java UK.co.demon.almide.util.pretty.Pretty [options] <javaSourceFile> [<PrettyOutputFile>]"

where [options] are:
  -a <int>        : Spaces after an operator
  -b <int>        : Spaces before an operator
  -e              : Only applies if the -r flag is set.  Disables -r flag for
                    special case of else if statement blocks
  -h              : help (this screen)
  -i <int>        : Indent Level
  -n              : Braces always begin on a new line
  -r              : Always make singleton statement blocks (such as if-then,
                    while, for, etc. into regular blocks with braces
  -v              : Version information



3   Test out the Pretty-printer
-------------------------------

OK so now let's do a preliminary test and type in:

    java  UK.co.demon.almide.util.pretty.Pretty  Philosophers.java

You should get a listing to the console screen.

Next, to produce the same output but to a file, type in:

    java UK.co.demon.almide.util.pretty.Pretty Philosophers.java Philosophers.bak

This now sends the Pretty-printer output to Philosophers.bak,
creating and overwriting any existing file of that name.  Study this
file. If you're satisfied it's working, you can optionally delete
Philosophers.java and rename Philosophers.bak to Philosophers.java.

If you're finding this Pretty-printer is going to be useful, (even
though ALPHA!) you should add it to the Java CLASSPATH so that you
can reformat Java sourcecode in _any_ directory on your system.



4   Adding the Pretty-printer to your CLASSPATH
-----------------------------------------------

In order to use the Pretty-printer in your day-to-day work, you must
make sure that it's accessible from your local machine's Java
CLASSPATH.  (For PC users, the CLASSPATH is usually set in
autoexec.bat).  To do this, simply add "/JavaPackageDir/Pretty.jar" to
your CLASSPATH variable in your machine's startup file.  Replace
"JavaPackageDir" with the directory you put Pretty.jar in, of course.



Final Comments
--------------

Instead of having to type in such a long command every time you want
to reformat your source:

    java  UK.co.demon.almide.util.pretty.Pretty  Philosophers.java

you may want to create a short system command name for it.  This can
be done on Windows systems by making a batch file (BAT), and on Unix
systems, with a shell script.

Here's my own (Windows) command to invoke the Pretty-printer:


------------------------------------------------------------Pretty.bat--
@ECHO OFF
REM invokes the Pretty-printer

java  UK.co.demon.almide.util.pretty.Pretty  %1 %1 -i4

:end
------------------------------------------------------------------------


in Unix c-shell (csh or it's derivatives) you can make an alias for
pretty:

    alias pretty 'java UK.co.demon.almide.util.pretty.Pretty \!*'


                             ---  0  ---

    Copyright (c) 1997 Sandy Anderson.  All Rights Reserved.

    THE AUTHOR MAKES NO  REPRESENTATIONS OR WARRANTIES  ABOUT THE SUITABILITY
OF THE SOFTWARE,  EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
IMPLIED WARRANTIES OF MERCHANTABILITY,  FITNESS FOR A PARTICULAR PURPOSE,  OR
NON-INFRINGEMENT.   THE AUTHOR  SHALL NOT BE LIABLE FOR  ANY DAMAGES SUFFERED
BY LICENSEE AS A RESULT OF USING,  MODIFYING OR DISTRIBUTING THIS SOFTWARE OR
ITS DERIVATIVES.

                             ---  0  ---


I hope you find the Pretty-printer useful in your Java work.  Please
do get in touch with me if you have any comments, observations or
suggestions about it.

Regards,



Sandy



P.S.

The sourcecode for Pretty, for those interested in parsing, JavaCC
and such like, is available at:

http://www.almide.demon.co.uk/source_code/java/JavaCC/Pretty/Pretty.html


/*  Correct my address in any reply, or it'll be treated as spam:
--                                                          
//     Alexander Anderson    <DELETE_THIS.sandy@almide.demon.co.uk>
//     Home Fone                               +44 (0) 171-794-4543
//     London, UK                    http://www.almide.demon.co.uk/ 
//     PGP print   C6 8C 55 F2 77 7B 99 9B  14 77 66 F5 B8 74 CF 12
*/

