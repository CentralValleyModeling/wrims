//@copyright_begin
// ================================================================
// Copyright Notice
// Copyright (C) 1998-2001 by Joe Linoff (www.joelinoff.com/ccdoc)
// 
// This software is distributed in the hope that it will be useful, but
// without WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// 
// Permission is granted to anyone to make or distribute altered copies
// of this software provided that the copyright notice and this
// permission notice are preserved, that the distributor grants the
// recipent permission for further distribution as permitted by this
// notice and that the origin of the software is represented correctly.
// 
// Comments and suggestions are always welcome.
// Please report bugs to http://www.joelinoff.com/ccdoc
// ================================================================
//@copyright_end

// MULTIPLE INCLUSION GUARD
#ifndef ccdoc_exceptions_h
#define ccdoc_exceptions_h

/**
 * This static variable allows the header version
 * to be queried at runtime.
 */
static char ccdoc_exceptions_h_rcsid[] = "$Id: exceptions.h,v 1.2 2001/08/30 03:36:01 Administrator Exp $";

#if defined(_MSC_VER)
#pragma warning ( disable : 4786 4251 )
#endif

#include <string>

using namespace std;

namespace ccdoc {
  namespace exceptions {
    /**
     * Base exception class.
     * @author Joe Linoff
     * @version $Id: exceptions.h,v 1.2 2001/08/30 03:36:01 Administrator Exp $
     */
    class base {
    public:
      /**
       * Default constructor.
       */
      base();
      /**
       * Id based constructor.
       * @param id The exception id.
       * @param file __FILE__.
       * @param lineno __LINE__.
       * @param msg Additional message text.
       */
      base(const char* id,const char* file,int lineno,const char* msg);
      /**
       * Destructor.
       */
      ~base();
      /**
       * Report the exception.
       */
      virtual void report() const;
    protected:
      string m_msg;
    };
    /**
     * Assertion exception.
     * @author Joe Linoff
     * @version $Id: exceptions.h,v 1.2 2001/08/30 03:36:01 Administrator Exp $
     */
    class assert_true : public ccdoc::exceptions::base {
    public:
      /**
       * Constructor.
       * @param file __FILE__
       * @param lineni __LINE__
       * @param expr The expression that resolved to false.
       */
      assert_true(const char* file,int lineno,const char* expr);
    };
    /**
     * Invalid database exception.
     * @author Joe Linoff
     * @version $Id: exceptions.h,v 1.2 2001/08/30 03:36:01 Administrator Exp $
     */
    class invalid_database : public ccdoc::exceptions::base {
    public:
      /**
       * @param file __FILE__
       * @param lineno __LINE__
       * @param dbfile The db file.
       * @param msg Additional information about the error.
       */
      invalid_database(const char* file,
		       int lineno,
		       const char* dbfile,
		       const char* msg);
    };
    /**
     * Duplicate_name exception.
     * @author Joe Linoff
     * @version $Id: exceptions.h,v 1.2 2001/08/30 03:36:01 Administrator Exp $
     */
    class duplicate_name : public ccdoc::exceptions::base {
    public:
      /**
       * @param file __FILE__
       * @param lineno __LINE__
       * @param name The duplicate name file.
       * @param msg Additional information about the error.
       */
      duplicate_name(const char* file,
		     int lineno,
		     const char* name,
		     const char* msg);
    };
    /**
     * Unwriteable output file.
     * @author Joe Linoff
     * @version $Id: exceptions.h,v 1.2 2001/08/30 03:36:01 Administrator Exp $
     */
    class unwriteable_output_file : public ccdoc::exceptions::base {
    public:
      /**
       * @param file __FILE__
       * @param lineno __LINE__
       * @param name The file name.
       */
      unwriteable_output_file(const char* file,
			      int lineno,
			      const char* name);
    };
  }
}

/**
 * assertion macro.
 */
#define ccdoc_assert(expr) \
  if( !(expr) ) { throw ccdoc::exceptions::assert_true(__FILE__,__LINE__,#expr); }

#endif
