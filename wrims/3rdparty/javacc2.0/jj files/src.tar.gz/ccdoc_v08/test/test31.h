// Verify the fix for issue 0074.
int test31;
