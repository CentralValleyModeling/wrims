// Verify test34 warning message.
int test34;
