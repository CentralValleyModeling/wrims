public class VBWriter
{
  public Object visit(SimpleNode node, Object data) { return data; }
  public Object visit(ASTCompilationUnit node, Object data) { return data; }
  public Object visit(ASTProcDeclaration node, Object data) { return data; }
  public Object visit(ASTStatements node, Object data) { return data; }
  public Object visit(ASTStatement node, Object data) { return data; }
  public Object visit(ASTAssignment node, Object data) { return data; }
  public Object visit(ASTMethodCall node, Object data) { return data; }
  public Object visit(ASTOnError node, Object data) { return data; }
  public Object visit(ASTIfStatement node, Object data) { return data; }
  public Object visit(ASTIfClause node, Object data) { return data; }
  public Object visit(ASTDoWhileStatement node, Object data) { return data; }
  public Object visit(ASTDoCondition node, Object data) { return data; }
  public Object visit(ASTWhileWendStatement node, Object data) { return data; }
  public Object visit(ASTForEachStatement node, Object data) { return data; }
  public Object visit(ASTForStatement node, Object data) { return data; }
  public Object visit(ASTWithStatement node, Object data) { return data; }
  public Object visit(ASTCaseStatement node, Object data) { return data; }
  public Object visit(ASTExitStatement node, Object data) { return data; }
  public Object visit(ASTName node, Object data) { return data; }
  public Object visit(ASTExprTest node, Object data) { return data; }
  public Object visit(ASTExpression node, Object data) { return data; }
  public Object visit(ASTBinOp node, Object data) { return data; }
  public Object visit(ASTUnaryOp node, Object data) { return data; }
  public Object visit(ASTPrimaryExpression node, Object data) { return data; }
  public Object visit(ASTLiteral node, Object data) { return data; }
  public Object visit(ASTLabel node, Object data) { return data; }
}
