// Verify the fix for issue 0091.
namespace test41 {
  double g_const = 10.5;
  enum g_enum {RED,BLACK};
  extern void g_fct();
  typedef void (*FCT)();
  class Test {
  public:
    void fct(g_enum fred = RED, double ethel = g_const);
    void fct(FCT f = g_fct);
    void fct(Test* arg1);
  };
}
