/**
 * This is a simple variable.
 * This test verifies issues 001, 002 and 003
 */
int test10;
