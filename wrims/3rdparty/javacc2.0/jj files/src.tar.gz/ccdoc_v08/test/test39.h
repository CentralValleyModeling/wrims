// Verify the fix for issues 0084 & 0087 & 0088
namespace test39 {
  class Exception {
  };
  class Test {
  public:
    /**
     * This function does stuff see
     * @link test39::Exception
     * for details.
     * @throws test39::Exception When bad stuff happens.
     * @since r24
     */
    void fct();
  }
}
