namespace test54 {
  template<class VALUE_TYPE>
  class Test
  { 
  public: 
    /** 
     * Reads from the instream to an object and returns a reference to
     * it.
     * First, a text defined in the constructor is written to the
     * ostream defined in the constructor. Then the instream defined
     * in the constructor is read to the internal object, using
     * operator>>(). A reference to the internal object is returned.
     */ 
    Input< ReturnPrimitiveInterface<const VALUE_TYPE&, const Event&> > in;
  };
}

