//@copyright_begin
// ================================================================
// Copyright Notice
// Copyright (C) 1998-2001 by Joe Linoff (www.joelinoff.com/ccdoc)
//
// This software is distributed in the hope that it will be useful, but
// without WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// Permission is granted to anyone to make or distribute altered copies
// of this software provided that the copyright notice and this
// permission notice are preserved, that the distributor grants the
// recipent permission for further distribution as permitted by this
// notice and that the origin of the software is represented correctly.
//
// Comments and suggestions are always welcome.
// Please report bugs to http://www.joelinoff.com/ccdoc
// ================================================================
//@copyright_end

// MULTIPLE INCLUSION GUARD
#ifndef ccdoc_log_h
#define ccdoc_log_h

/**
 * This static variable allows the header version
 * to be queried at runtime.
 */
static char ccdoc_log_h_rcsid[] = "$Id: log.h,v 1.2 2001/08/21 18:47:30 Administrator Exp $";

#if defined(_MSC_VER)
#pragma warning ( disable : 4786 4251 )
#endif

#include "exceptions.h"
#include <string>
#include <vector>
#include <iostream>

using namespace std;

namespace ccdoc {
  /**
   * Log stream.
   * @author Joe Linoff
   * @version $Id: log.h,v 1.2 2001/08/21 18:47:30 Administrator Exp $
   */
  class log {
  public:
    log();
    ~log();
    log& operator << (const char*);
    log& operator << (const string&);
    log& operator << (const vector<string>&);
    log& operator << (char);
    log& operator << (unsigned char);
    log& operator << (int);
    log& operator << (unsigned int);
    log& operator << (long);
    log& operator << (unsigned long);
    log& operator << (ostream& (fct)(ostream&));
    log& operator << (log& x) {return x;}
    log& flush();
    void insert(ostream*);
    void insert(string&);
    void remove(ostream*);
    void remove(string&);
  public:
    /**
     * Disable the output log.
     * Nothing gets written.
     * @returns The log stream.
     */
    log& disable() {m_output_flag = false; return *this;}
    /**
     * Enable the output log.
     * Everything gets written.
     * @returns The log stream.
     */
    log& enable() {m_output_flag = true; return *this;}
  public:
    bool warnings_enabled() const {return m_warnings_flag;}
    void disable_warnings() {m_warnings_flag = false;}
    void enable_warnings() {m_warnings_flag = true;}
    void warnings(unsigned n) {m_warnings=n;}
    unsigned warnings() const {return m_warnings;}
    log& warning();
  public:
    void errors(unsigned n) {m_errors=n;}
    unsigned errors() const {return m_errors;}
    log& error();
  private:
    vector<ostream*> m_os;
    bool m_output_flag;
    bool m_warnings_flag;
    unsigned m_warnings;
    unsigned m_errors;
  };
  /**
   * Global log variable.
   */
  extern log s_log;
};

/**
 * Debugging aid.
 * It can be sprinkled throughout the code to
 * determine whether a statement was reached.
 * It is only used during development.
 */
#define CCDOC_DEBUG_MADE_IT \
  ccdoc::s_log << "DEBUG:" << __FILE__ << ":" << __LINE__ << "\n"

#endif
