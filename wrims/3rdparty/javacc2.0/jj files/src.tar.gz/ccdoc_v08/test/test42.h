// Verify fix for issue 0085.
namespace test42 {
  class A {
  public:
    /** default constructor */
    A() : m_x(0) {}
  private:
    int m_x;
  };
  class B {
  public:
    /** default constructor */
    B() {}
  };
  class Test {
  public:
    /** default constructor */
    Test() : x(0), y(0) {}
  private:
    int x,y;
  };
}
