// Issue 0054
// Verify that typedef handling works correctly.
typedef struct test26_s1 {
  int m_i1;
  int m_i2;
} test26_s1_type;

typedef struct {
  int m_i1;
  int m_i2;
} test26_s2_type;
