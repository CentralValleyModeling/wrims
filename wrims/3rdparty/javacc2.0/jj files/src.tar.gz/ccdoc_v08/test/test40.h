// Verify the fix for issue 0089 - javadoc short description compliancy.
namespace test40 {
  class Test {
  public:
    /**
     * Simple short description.
     */
    void fct1();
    /**
     * Simple short description with trailing space. 
     */
    void fct2();
    /**
     * Simple short description with trailing tab.	
     */
    void fct3();
    /**
     * Simple short description with trailing newline.
     * Simple long description.
     */
    void fct4();
    /**
     * Simple short description. Simple long description.
     */
    void fct5();
    /**
     * Simple short description. Simple
     * long description.
     */
    void fct6();
    /**
     * Short description with embedded periods.&nbsp;This is another short
     * description sentence.
     * Simple long description.
     */
    void fct7();
  };
};
