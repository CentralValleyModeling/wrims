// Verify issue 0063:
class test27 {
};
int test27_fct();
