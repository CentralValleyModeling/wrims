// Verify the fix for issue 0072.
class test32 {
public:
  typedef BB BB;
  typedef AA AA;
public:
  void B();
  void A();
};
