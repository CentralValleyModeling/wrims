// ================================================================
// Version: ccdoc v0.8 r14 2001/09/07 bin_opt_msvc_MSWin32-4.0
//
// Contact Info: mrprk@hotmail.com
//
// Shell: cmd.exe
//
// Platform: Windows 2000
// 
// It seems to be reporting a link and link text in the contents of a package
// as the value (it is a static global variable). There are two and the
// comments are generated correctly, but the link goes to the first one.
//
// Here is the snippet of code with comments:
// ================================================================
typedef int   Bool;
#define true  1
#define false 0

/**
 * Global boolean value to signal if an account is loaded.
 *
 * @author  Paul Kohler
 */
static Bool g_bAccountInit = false;

/**
 * Global boolean value to signal if the connection has been established.
 *
 * @author  Paul Kohler
 * @see IConnect
 */
static Bool g_bConnected = false;
