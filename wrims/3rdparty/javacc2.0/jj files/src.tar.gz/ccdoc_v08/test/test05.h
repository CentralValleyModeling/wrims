// Pre-processing tests.

// This s/b ignored.
#include <algorithm>

// This s/b ignored.
 # include <vector>

// This s/b ignored.
 # \
  include \
  <string>

// This s/b ignored.
#pragma myoff

#ifdef __ccdoc__
// This s/b ignored.
#error "This s/b ignored."
#endif

#define M3 M1
#define M1 10
#define M2 M1
#define M4 a+b
#define M5

#if 0
#error "This statement should be rejected."
#endif

#if 1
int accept_0 = 0;
#endif

#if M1
int accept_1 = 0;
#endif

#ifdef M1
int accept_2 = 0;
#endif

#ifndef M1
int reject_3 = 0;
#endif

#ifdef M1
int accept_4 = 0;
#else
int reject_5 = 0;
#endif

#ifdef Mx
int reject_6 = 0;
#else
int accept_7 = 0;
#endif

// Check nesting
#ifdef M1
#  ifdef M2
#   ifdef M3
int accept_8 = 0;
#   else
int reject_9 = 0;
#   endif
#  else
int reject_10 = 0;
#  endif
#endif

// Make sure that unrecognized tokens are reported in #if expressions.
#if defined __ccdoc__
#if 0 && ^1
#endif
#endif

// Start with a simple expression.
#if defined __ccdoc__
int accept_11 = 0;
#else
int reject_12 = 0;
#endif

#if defined ( __ccdoc__ )
int accept_13 = 0;
#else
int reject_14 = 0;
#endif

#if defined ( __ccdoc__ )
// This does not parse correctly for some compilers.
#if defined ( ( ( __ccdoc__ ) ) )
int accept_15 = 0;
#else
int reject_16 = 0;
#endif
#endif

#if ! defined ( __NOT_DEFINED__ )
int accept_17 = 0;
#endif

// ================================================================
//
// Simple AND expressions.
//
// ================================================================
#if defined ( __ccdoc__ ) && ! defined ( __NOT_DEFINED__ )
int accept_18 = 0;
#endif

#if defined ( __ccdoc__ ) && ! defined ( __NOT_DEFINED__ ) && ! defined NDDD
int accept_19 = 0;
#endif

#if defined ( __ccdoc__ ) && ( ! defined ( __NOT_DEFINED__ ) && ! defined ND )
int accept_20 = 0;
#endif

#if defined( __ccdoc__ ) && (( ! defined( __NOT_DEFINED__ ) && ! defined ND ))
int accept_21 = 0;
#endif

#if (defined(__ccdoc__) && !defined(ND1) && !defined ND2)
int accept_22 = 0;
#endif

#if (defined(__ccdoc__) && !defined(ND1) && !defined ND2)
int accept_23 = 0;
#endif

#if (defined(__ccdoc__) && (!defined(ND1) && !defined ND2))
int accept_24 = 0;
#endif

#if (defined(__ccdoc__) && (!defined(ND1) && (!defined ND2)))
int accept_25 = 0;
#endif

// ================================================================
//
// Simple OR expressions.
//
// ================================================================
#if defined ( __ccdoc__ ) || ! defined ( __NOT_DEFINED__ )
int accept_30 = 0;
#endif

#if defined(ND1) || defined(ND2) || defined(M3)
int accept_31 = 0;
#endif

#if (defined(ND1) || (defined(ND2) || defined(M3)))
int accept_32 = 0;
#endif

#if (defined(ND1) || defined(ND2) || defined(M3))
int accept_33 = 0;
#endif

// ================================================================
//
// EQ operator expressions.
//
// ================================================================
#define M10 10

#if M10 == 10
int accept_40 = 0;
#endif

#if ( M10 == 10 )
int accept_41 = 0;
#endif

#if ( (M10) == (10) )
int accept_42 = 0;
#endif

#if (((M10)==(10)))
int accept_43 = 0;
#endif

#if M10 == 11
int reject_44 = 0;
#else
int accept_45 = 0;
#endif

// ================================================================
//
// NE operator expressions.
//
// ================================================================
#if M10 != 11
int accept_50 = 0;
#endif

#if M10 != 10
int reject_51 = 0;
#else
int accept_52 = 0;
#endif

// ================================================================
//
// LT operator expressions.
//
// ================================================================
#if M10 < 11
int accept_60 = 0;
#endif

#if M10 < 8
int reject_61 = 0;
#else
int accept_62 = 0;
#endif

// ================================================================
//
// LE operator expressions.
//
// ================================================================
#if M10 <= 11
int accept_70 = 0;
#endif

#if M10 <= 10
int accept_71 = 0;
#endif

#if M10 <= 8
int reject_72 = 0;
#else
int accept_73 = 0;
#endif

// ================================================================
//
// GT operator expressions.
//
// ================================================================
#if M10 > 8
int accept_80 = 0;
#endif

#if M10 > 11
int reject_81 = 0;
#else
int accept_82 = 0;
#endif

// ================================================================
//
// GE operator expressions.
//
// ================================================================
#if M10 >= 8
int accept_90 = 0;
#endif

#if M10 >= 10
int accept_91 = 0;
#endif

#if M10 >= 11
int reject_92 = 0;
#else
int accept_93 = 0;
#endif

// ================================================================
//
// Numeric tests. Make sure that hex, oct and dec work.
//
// ================================================================
#define N1 10
#define N2 0x10

#if N1 == 10
int accept_100 = 0;
#endif

#if N1 == 0xa
int accept_101 = 0;
#endif

#if N1 == 0xA
int accept_102 = 0;
#endif

#if N1 == 012
int accept_103 = 0;
#endif

#if N2 == 16
int accept_104 = 0;
#endif

#if N2 == 020
int accept_105 = 0;
#endif

#if N2 == 0x10
int accept_106 = 0;
#endif

#define NXf 0xf
#define NXe 0xe
#define NXd 0xd
#define NXc 0xc
#define NXb 0xb
#define NXa 0xa
#define NXff 0xff

#if NXf == 15
int accept_110 = 0;
#endif
#if NXe == 14
int accept_111 = 0;
#endif
#if NXd == 13
int accept_112 = 0;
#endif
#if NXc == 12
int accept_113 = 0;
#endif
#if NXb == 11
int accept_114 = 0;
#endif
#if NXa == 10
int accept_115 = 0;
#endif
#if NXff == 255
int accept_116 = 0;
#endif

#define NXF 0XF
#define NXE 0XE
#define NXD 0XD
#define NXC 0XC
#define NXB 0XB
#define NXA 0XA
#define NXFF 0XFF

#if NXF == 15
int accept_120 = 0;
#endif
#if NXE == 14
int accept_121 = 0;
#endif
#if NXD == 13
int accept_122 = 0;
#endif
#if NXC == 12
int accept_123 = 0;
#endif
#if NXB == 11
int accept_124 = 0;
#endif
#if NXA == 10
int accept_125 = 0;
#endif
#if NXFF == 255
int accept_126 = 0;
#endif

// ================================================================
//
// #elif test cases.
//
// ================================================================
#define X1 1

#if defined(X3)
int reject_130 = 0;
#elif defined(X1) && X1 == 1
int accept_131 = 0;
#elif defined(X1) && X1 > 1
int reject_132 = 0;
#else
int reject_133 = 0;
#endif

#if defined(X1)
int accept_140 = 0;
#elif defined(X1) && X1 == 1
int reject_141 = 0;
#elif defined(X1) && X1 > 1
int reject_142 = 0;
#else
int reject_143 = 0;
#endif

#if defined(X2)
int reject_150 = 0;
#elif defined(X2) && X2 == 1
int reject_151 = 0;
#elif defined(X2) && X2 > 1
int reject_152 = 0;
#else
int accept_153 = 0;
#endif

// ================================================================
//
// Random test cases.
//
// ================================================================
#define VERSION 0x01F

#if ( defined(VERSION) && VERSION >= 0x01F )
int accept_200 = 0;
#endif

// ================================================================
//
// # line directives.
//
// ================================================================
// This s/b ignored.
#line 10

// This s/b ignored.
#line 11 "foo.cc"

// Solaris compiler thingy, it is also accepted by the GNU compiler.
#80 "test07.ccx"

// Used to avoid compilation warnings.
int foo() {return 0;}

// ================================================================
//
// Test pre-processing symbolic comparisons.
//
// ================================================================
#define __TEST07_300_NOT_LEFT
#define __TEST07_300_LEFT
#define __TEST07_300 __TEST07_300_LEFT
#if ( __TEST07_300 == __TEST07_300_LEFT )
int accept_300 = 0;
#endif 
#if ( __TEST07_300 != __TEST07_300_NOT_LEFT )
int accept_301 = 0;
#endif 

#define __TEST07_310_NOT_RIGHT
#define __TEST07_310_RIGHT
#define __TEST07_310 __TEST07_310_RIGHT
#if ( __TEST07_310_RIGHT == __TEST_310 )
int accept_310 = 0;
#endif 
#if ( __TEST07_310_NOT_RIGHT != __TEST_310 )
int accept_311 = 0;
#endif 

// ================================================================
//
// Miscellaneous tests
//
// ================================================================
#if defined(__MSL__) && __MSL__ <= 0x51FF // test
#   define __STL_WCHAR_MSL_EXCLUDE 1
# endif

