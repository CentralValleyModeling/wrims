// Issue 0052
const char  test25_ESCAPE_CHAR = '\\';
const char  test25_HIDASH      = '\xad';
const char  test25_BLANKCHR    = ' ';
const char  test25_DQUOTECHR   = '"';
const char  test25_SQUOTECHR   = '\'';
const char  test25_LINECONTCHR = '\\';
const char  test25_COMMENTCHR  = '#';
const int   test25_BIGBUF      = 2048;
