// Issue 0046
class test22 {
public:
  /**
   * Do stuff.
   * @see #fct 1
   * @see #fct 2
   */
  void fct();
  void fct(int);
  void fct(double);
};
