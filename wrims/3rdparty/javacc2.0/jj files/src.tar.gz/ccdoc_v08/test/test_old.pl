#!c:/Perl/bin/perl -w
use strict;

my $s_total = 0;
my $s_failed = 0;
my $s_passed = 0;

&Main;

# ================================================
# MAIN
# ================================================
sub Main {
  if( $#ARGV < 1 ) {
    print STDERR "ERROR: missing arguments [file] [testid]\n";
    return 1;
  }
  my $prog = $ARGV[0];

  # Initialize
  $main::s_total = 0;
  $main::s_passed = 0;
  $main::s_failed = 0;

  # Clean out the old stuff.
  opendir(DIR, "test") || die "can't opendir test: $!";
  my @test_files = grep { /^[^\.]/ && -f "test/$_" } readdir(DIR);
  closedir DIR;
  my $test_file;
  foreach $test_file ( @test_files ) {
    unlink "DEBUG: $test_file\n";
  }

  # Run the tests
  &Test01($prog);
  &Test02($prog);
  &Test03($prog);
  &Test04($prog);
  &Test05($prog);
  &Test06($prog);
  &Test07($prog);
  &Test08($prog);
  &Test09($prog);
  &Test10($prog);
  &Test11($prog);
  &Test12($prog);
  &Test13($prog);
  &Test14($prog);

  # ================================================
  # Report the test summary.
  # ================================================
  my $total  = $main::s_total;
  my $passed = $main::s_passed;  my $failed = $main::s_failed;
  print ":summary:${total}:${passed}:${failed}\n";
  print ":FAILED\n" if ( $failed );
  print ":PASSED\n" if ( ! $failed );
  exit $failed;
}
# ================================================
# Test simple root page generation.
# ================================================
sub Test01
  {
    my $prog = shift;
    my $id = "01";

    my $db = "test/test${id}.db";
    my $df = "test/test${id}*";
    my $html = "test/test${id}.";
    my $log = "test/test${id}.log";
    my $ok = "test${id}.ok";
    my $pe = "-putenv CCDOC_PHASE1_DEBUG=1";
    my $pkg = "-pkg test${id}";
    my $sws = "-args -nocout -log $log -rootfile test/test${id}.ccdoc.index.html";

    &Run("$prog $sws -db $db -html $html test01.cc");
    my $errcnt = &FilterAndCompareOk("test/test01.ccdoc.index.html",
				     "test01.ok",
				     "test_filter1.pl");
    &DeleteFiles($df) if ( $errcnt == 0 );
  }
# ================================================
# Test simple root page generation with different
# fg and bg colors.
# ================================================
sub Test02
  {
    my $prog = shift;
    my $id = "02";

    my $db = "test/test${id}.db";
    my $df = "test/test${id}*";
    my $html = "test/test${id}.";
    my $log = "test/test${id}.log";
    my $ok = "test${id}.ok";
    my $pe = "-putenv CCDOC_PHASE1_DEBUG=1";
    my $pkg = "-pkg test${id}";
    my $sws = "-args -nocout -log $log -bg black -fg white -rootfile test/test${id}.ccdoc.index.html";

    &Run("$prog $sws -db $db -root \"Black & White Test\" -html $html");
    my $errcnt = &FilterAndCompareOk("test/test02.ccdoc.index.html",
				     "test02.ok",
				     "test_filter1.pl");
    &DeleteFiles($df) if ( $errcnt == 0 );
  }
# ================================================
# Verify that the help message is correct.
# ================================================
sub Test03
  {
    my $prog = shift;
    my $id = "03";

    my $db = "test/test${id}.db";
    my $df = "test/test${id}*";
    my $html = "test/test${id}.";
    my $log = "test/test${id}.log";
    my $ok = "test${id}.ok";
    my $pe = "-putenv CCDOC_PHASE1_DEBUG=1";
    my $pkg = "-pkg test${id}";
    my $sws = "-nocout -log $log";

    &Run("$prog $sws -h");
    my $errcnt = &CompareOk($log,$ok);
    # DeleteFiles is not needed here because
    # the log file is deleted in CompareOk().
  }
# ================================================
# Basic C++ token parsing tests.
# ================================================
sub Test04
  {
    my $prog = shift;
    my $id = "04";

    my $db = "test/test${id}.db";
    my $df = "test/test${id}*";
    my $html = "test/test${id}.";
    my $log = "test/test${id}.log";
    my $ok = "test${id}.ok";
    my $pe = "-putenv CCDOC_PHASE1_DEBUG=1";
    my $pkg = "-pkg test${id}";
    my $sws = "-nocout -log $log";

    &Run("$prog -db $db $sws $pe test${id}.cc");
    my $errcnt = &CompareOk($log,$ok);
    &DeleteFiles($df) if ( $errcnt == 0 );
  }
# ================================================
# Basic ccdoc token parsing tests for C++ '/* .. */'
# multi-line comments.
# ================================================
sub Test05
  {
    my $prog = shift;
    my $id = "05";

    my $db = "test/test${id}.db";
    my $df = "test/test${id}*";
    my $html = "test/test${id}.";
    my $log = "test/test${id}.log";
    my $ok = "test${id}.ok";
    my $pe = "-putenv CCDOC_PHASE1_DEBUG=1";
    my $pkg = "-pkg test${id}";
    my $sws = "-nocout -log $log";

    &Run("$prog -db $db $sws $pe test${id}.cc");
    my $errcnt = &CompareOk($log,$ok);
    &DeleteFiles($df) if ( $errcnt == 0 );
  }
# ================================================
# Basic ccdoc token parsing tests for C++ '//' single-line comments.
# ================================================
sub Test06
  {
    my $prog = shift;
    my $id = "06";

    my $db = "test/test${id}.db";
    my $df = "test/test${id}*";
    my $html = "test/test${id}.";
    my $log = "test/test${id}.log";
    my $ok = "test${id}.ok";
    my $pe = "-putenv CCDOC_PHASE1_DEBUG=1";
    my $pkg = "-pkg test${id}";
    my $sws = "-nocout -log $log";

    &Run("$prog -db $db $sws $pe test${id}.cc");
    my $errcnt = &CompareOk($log,$ok);
    &DeleteFiles($df) if ( $errcnt == 0 );
  }
# ================================================
# Basic ccdoc pre-processing tests
# ================================================
sub Test07
  {
    my $prog = shift;
    my $id = "07";

    my $db = "test/test${id}.db";
    my $df = "test/test${id}*";
    my $html = "test/test${id}.";
    my $log = "test/test${id}.log";
    my $ok = "test${id}.ok";
    my $pe = "-putenv CCDOC_PHASE1_DEBUG=1";
    my $pkg = "-pkg test${id}";
    my $sws = "-nocout -log $log";

    &Run("$prog -db $db $pkg $sws $pe test${id}.cc");
    my $errcnt = &CompareOk($log,$ok);
    &DeleteFiles($df) if ( $errcnt == 0 );
}
# ================================================
# Basic C++ tests
# ================================================
sub Test08
  {
    my $prog = shift;
    my $id = "08";

    my $db = "test/test${id}.db";
    my $df = "test/test${id}*";
    my $html = "test/test${id}.";
    my $log = "test/test${id}.log";
    my $ok = "test${id}.ok";
    my $pe = "-putenv CCDOC_PHASE1_DEBUG=1";
    my $pkg = "-pkg test${id}";
    my $sws = "-nocout -log $log";

    &Run("$prog -db $db $pkg $sws $pe test${id}.cc");
    my $errcnt = &CompareOk($log,$ok);
    &DeleteFiles($df) if ( $errcnt == 0 );
}
# ================================================
# Make sure that old file records are removed
# properly when duplicate files are input.
# ================================================
sub Test09
  {
    my $prog = shift;
    my $id = "09";

    my $db = "test/test${id}.db";
    my $df = "test/test${id}*";
    my $html = "test/test${id}.";
    my $log = "test/test${id}.log";
    my $ok = "test${id}.ok";
    my $pe = "-putenv CCDOC_PHASE3_DEBUG=1";
    my $pkg = "-pkg test${id}";
    my $sws = "-nocout -log $log";

    &Run("$prog -html $html -db $db $pkg $sws $pe test${id}.cc test${id}.cc");
    my $errcnt = &CompareOk($log,$ok);
    &DeleteFiles($df) if ( $errcnt == 0 );
}
# ================================================
# Make sure that '::' can be used to separate
# package entities on the command line.
# ================================================
sub Test10
  {
    my $prog = shift;
    my $id = "10";

    my $db = "test/test${id}.db";
    my $df = "test/test${id}*";
    my $html = "test/test${id}.";
    my $log = "test/test${id}.log";
    my $ok = "test${id}.ok";
    my $pe = "-putenv CCDOC_PHASE3_DEBUG=1";
    my $pkg = "-pkg test10::pkg1::pkg2";
    my $sws = "-nocout -log $log";

    &Run("$prog -html $html -db $db $pkg $sws $pe test09.cc");
    my $errcnt = &CompareOk($log,$ok);
    &DeleteFiles($df) if ( $errcnt == 0 );
}
# ================================================
# Make sure that '.' can be used to separate
# package entities on the command line.
# ================================================
sub Test11
  {
    my $prog = shift;
    my $id = "11";

    my $db = "test/test${id}.db";
    my $df = "test/test${id}*";
    my $html = "test/test${id}.";
    my $log = "test/test${id}.log";
    my $ok = "test${id}.ok";
    my $pe = "-putenv CCDOC_PHASE3_DEBUG=1";
    my $pkg = "-pkg test11.pkg1.pkg2";
    my $sws = "-nocout -log $log";

    &Run("$prog -html $html -db $db $pkg $sws $pe test09.cc");
    my $errcnt = &CompareOk($log,$ok);
    &DeleteFiles($df) if ( $errcnt == 0 );
}
# ================================================
# Verify that '.' and '::' can be used to
# separate \@pkgdoc entries.
# ================================================
sub Test12
  {
    my $prog = shift;
    my $id = "12";

    my $db = "test/test${id}.db";
    my $df = "test/test${id}*";
    my $html = "test/test${id}.";
    my $log = "test/test${id}.log";
    my $ok = "test${id}.ok";
    my $pe = "-putenv CCDOC_PHASE3_DEBUG=1";
    my $pkg = "";
    my $sws = "-nocout -log $log";

    &Run("$prog -html $html $pkg -db $db $sws $pe test${id}.cc");
    my $errcnt = &CompareOk($log,$ok);
    &DeleteFiles($df) if ( $errcnt == 0 );
}
# ================================================
# Verify that extern processing works:
# extern "C" {
#   void f1();
#   void f2();
#   void f3();
# }
# ================================================
sub Test13
  {
    my $prog = shift;
    my $id = "13";

    my $db = "test/test${id}.db";
    my $df = "test/test${id}*";
    my $html = "test/test${id}.";
    my $log = "test/test${id}.log";
    my $ok = "test${id}.ok";
    my $pe = "";
    my $pkg = "-pkg test${id}";
    my $sws = "-nocout -log $log";

    &Run("$prog -html $html $pkg -db $db $sws $pe test${id}.cc");
    my $errcnt = &CompareOk($db,$ok);
    &DeleteFiles($df) if ( $errcnt == 0 );
}
# ================================================
# Verify that rptim works.
# ================================================
sub Test14
  {
    my $prog = shift;
    my $id = "14";

    my $db = "test/test${id}.db";
    my $df = "test/test${id}*";
    my $html = "test/test${id}.";
    my $log = "test/test${id}.log";
    my $ok = "test${id}.ok";
    my $pe = "";
    my $pkg = "-pkg test${id}";
    my $sws = "-nocout -log $log";

    &Run("$prog -html $html $pkg -db $db $sws $pe test${id}.cc");
    my $errcnt = &CompareOk($db,$ok);
    &DeleteFiles($df) if ( $errcnt == 0 );
}
# ================================================
# Delete files
# ================================================
sub DeleteFiles
  {
    my $pattern = shift;
    &Run("rm $pattern");
  }
# ================================================
# Run a command.
# ================================================
sub Run
  {
    my $cmd = shift;

    #print "CMD: $cmd\n";
    my $st = system("$cmd");
    $st = $st >> 8;
    return $st;
  }
# ================================================
# Filter and Compare with an OK file.
# ================================================
sub FilterAndCompareOk
  {
    my $file = shift;
    my $okfile = shift;
    my $filter = shift;

    my $err = 0;

    $err += &Exists("$filter");
    $err += &Exists("$file");
    $err += &Exists("$okfile");

    $err += &Filter("${file}","$filter");
    $err += &Filter("${okfile}","$filter");

    if ( ! $err ) {
      my $st = &Run("diff --brief -w ${file}.tmp ${okfile}.tmp");
      if( $st == 0 ) {
	&Passed("compareok-${file}");
	unlink("$file");
	unlink("$file.tmp");
	unlink("$okfile.tmp");
      }
      else {
	&Failed("compareok-${file}");
	$err++;
      }
    }
    else {
      &Failed("compareok-${file}");
      $err++;
    }
    return $err;
  }
# ================================================
# Compare with an OK file.
# ================================================
sub CompareOk
  {
    my $file = shift;
    my $okfile = shift;

    my $err = 0;
    $err += &Exists("$file");
    $err += &Exists("$okfile");

    if ( ! $err ) {
      my $st = &Run("diff --brief -w ${file} ${okfile}");
      if( $st == 0 ) {
	&Passed("compareok-${file}");
	unlink("$file");
      }
      else {
	$err++;
	&Failed("compareok-${file}");
      }
    }
    else {
      $err++;
      &Failed("compareok-${file}");
    }
    return $err;
}
# ================================================
# Filter
# ================================================
sub Filter
  {
    my $file = shift;
    my $filter = shift;

    if ( ! -e "$filter" ) {
      &Failed("filter-${file}");
      return 1;
    }

    if ( ! -e "$file" ) {
      &Failed("filter-${file}");
      return 1;
    }

    my $st = &Run("perl $filter $file $file.tmp");
    if ( $st ) {
      &Failed("filter-${file}");
      return 1;
    }

    &Passed("filter-${file}");
    return 0;
  }
# ================================================
# Test for file existence.
# ================================================
sub Exists
  {
    my $file = shift;
    if( ! -e $file ) {
      &Failed("exists-${file}");
      return 1;
    }
    &Passed("exists-${file}");
    return 0;
  }
# ================================================
# failed
# ================================================
sub Failed
  {
    my $id = shift;
    print ":test:${id}:failed\n";
    $main::s_failed++;
    $main::s_total++;
  }
# ================================================
# passed
# ================================================
sub Passed
  {
    my $id = shift;
    print ":test:${id}:passed\n";
    $main::s_passed++;
    $main::s_total++;
  }
