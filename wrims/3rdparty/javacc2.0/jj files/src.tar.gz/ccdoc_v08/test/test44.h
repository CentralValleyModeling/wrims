// Verify fix for issue 0090.
namespace test44 {
  /** No args */
  void fct();
  /** Int arg */
  void fct(int);
  /** Cstring arg */
  void fct(const char*);

  class Test {
  public:
    enum FOO {BAR,SPAM};
    /**
     * This function references {@link test44::fct fct} to
     * handle stuff.
     */
    void fct1();
    /**
     * {@link test44::fct prefix} suffix stuff.
     */
    void fct2();
    /**
     * prefix stuff {@link test44::fct suffix}
     * @see #fct1
     */
    void fct3();
    /**
     * multiple refs {@link test44::fct m1} {@link #fct1 m2} {@link #FOO EN} .
     */
    void fct4();
    /**
     * txt {@link test44::fct m1} txt {@link #fct1 m2} txt {@link #fct2 m3} txt
     */
    void fct5();
    /**
     * {@link test44::fct m1} txt {@link #fct1 m2} txt {@link #fct2 m3} txt
     */
    void fct6();
    /**
     * {@link test44::fct m1} {@link #fct1 m2} txt {@link #fct2 m3} txt
     */
    void fct7();
    /**
     * {@link test44::fct m1} {@link #fct1 m2} {@link #fct2 m3} txt
     */
    void fct8();
    /**
     * {@link test44::fct m1} {@link #fct1 m2} {@link #fct2 m3}
     */
    void fct9();
    /**
     * {@link test44::fct m1}{@link #fct1 m2}{@link #fct2 m3}
     */
    void fcta();
  }
}
