// Verify the fix for issue 0099 - default constructor not generated.
namespace test55 {
  class Test {
  public:
    Test(int);
  };
}
