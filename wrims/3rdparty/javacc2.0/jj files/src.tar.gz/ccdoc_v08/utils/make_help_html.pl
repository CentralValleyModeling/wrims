#!c:/Perl/bin/perl -w
#
# Make help.html from help.txt.
#
use strict;

&Main;

# ================================================
# MAIN
# ================================================
sub Main
  {
    open(TXT,"help.txt") || die "ERROR: Can't read 'help.txt'.\n"; 
    open(HTML,">help.html") || die "ERROR: Can't write 'help.html'.\n";
    print HTML "<html>\n";
    print HTML "<body>\n";
    print HTML "<pre>\n";
    while(<TXT>)
      {
	if( /^$/ ) {
	  print HTML "<br>\n";
	  next;
	}
	s/\&/&amp;/g;
	s/\</&lt;/g;
	s/\>/&gt;/g;
	print HTML $_;
      }
    print HTML "</pre>\n";
    print HTML "</body>\n";
    print HTML "</html>\n";
    close(HTML);
    close(TXT);
  }
