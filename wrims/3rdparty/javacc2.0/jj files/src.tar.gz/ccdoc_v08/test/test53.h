namespace test53 {
  
#define std__string     std::string
#define std__vector(T)  std::vector<T >
  
/**
 * Test
 */
  class Test
  {
  public:
    /** My prefix String. */
    std__string                 m_str;
    
    /** My prefix Vector. */
    std__vector(std__string)    m_vec;
    
    /** My prefix Function. */
    void func(std__string str) const;
    
    int  m_int;   //@- My suffix integer.
    char m_char;  //@- My suffix char.
    long m_long;  //@- My suffix long.
  };
}

#if 0
namespace test66
{
  class Test
  {
  public:
    Test operator()();
    Test operator=();
    Test operator==();
    Test operator!=();
    Test operator<();
    Test operator<=();
    Test operator>();
    Test operator>=();
    Test operator+();
    Test operator-();
    Test operator*();
    Test operator/();
    Test operator~();
    Test operator&();
    operator int();
    operator unsigned long ();
    operator unsigned long long ();
    operator char** ();
    operator char* ();
  };
}
#endif
