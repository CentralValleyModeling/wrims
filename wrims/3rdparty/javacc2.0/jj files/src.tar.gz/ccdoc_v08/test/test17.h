/**
 * Issue 0036: Comments are getting lost.
 */

/**
 * Function A documentation.
 */
int test17();
