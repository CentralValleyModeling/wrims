// Test for issue 0015 fix.
class A {
public:
  void foo() throw (my_exception);
  void PlotDown(const doc::CC* pCC) const throw RunTimeError;
};
