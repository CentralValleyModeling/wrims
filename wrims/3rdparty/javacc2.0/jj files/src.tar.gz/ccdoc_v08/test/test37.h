// Verify that the -putenv switch works.
int test37 = 0;
