namespace test46
{
  class Test {
  private:
    void fct(int);
  public:
    /** public fct */
    void fct();
    /**
     * See {@link test64::A::fct fct} for more information.
     */
    void fct1();
  };
}
