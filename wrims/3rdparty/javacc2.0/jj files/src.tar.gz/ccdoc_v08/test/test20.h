// Test for issue 44.
class test20_outer {
public:
  class test20_inner1 {
  public:
    class test20_inner11 {
    };
    class test20_inner12 {
    };
  };
  class test20_inner2 {
  public:
    class test20_inner21 {
    };
    class test20_inner22 {
    };
  };
};

