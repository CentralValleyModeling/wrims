// Verify fix for issue 0050.
class test24 {
public:
  int fct2( void ( * fp ) ( ) ) ;
};

