// Verify fix for issue 0117
namespace test51 {
  class Test
  {
  public:
    // Issue 0117
    void Set(int a);
    void Set(char *cp, int a);
  };
  void Test::Set(int a)
  {
    /** Set one. Red */
  }
  void Test::Set(char *cp, int a)
  {
    /** Set two. Yellow */
  }
}
