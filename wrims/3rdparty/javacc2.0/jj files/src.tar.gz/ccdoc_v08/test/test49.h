// Verify fix for issue 0114
namespace test49 {
  class Test
  {
  public:
    Test operator unsigned long();
  };
}

