// Category tests.
asm ( ".WORD 0,0" ); // REJECTED - asm

#define M1 // ACCEPTED - variable

namespace N1 {
};

using namespace N1; // REJECTED - using

class CLASS1; // REJECTED - forward declaration
class CLASS2 // ACCEPTED - class
{
public:
  typedef CLASS1* type1; // ACCEPTED - class type
public:
  enum {E1,E2}; // ACCEPTED - anonymous class enum
  enum {E3,E4} m_e; // ACCEPTED - anonymous class enum and variable
  enum DEF_E {E5,E6}; // ACCEPTED - class enum
private:
  int m_a; // ACCEPTED - class variable
public:
  int f(); // ACCEPTED - class function
};

//@{ N1 comment //@}
namespace N1 {
  //@{ N2 comment //@}
  namespace N2 {
    //@{ CLASS3 comment //@}
    class CLASS3 : public CLASS2 {
      //@{
      // CLASS3_SUB comment
      //@}
      class CLASS3_SUB {
      public:
	CLASS3_SUB();
	~CLASS3_SUB();
      };
    public:
      CLASS3();
      ~CLASS3();
    };
  }
}
/**
 * See the nested stuff.
 */
class CLASS4 {
public:
  /**
   * @see N1::N2::CLASS3
   */
  CLASS4( N1::N2::CLASS3 );
};

//@{ Simple function //@}
template<class T> void foo(T& v) {}

//@{ Function typedef //@}
int (*fct)(void) = 0;

int suffix_test();
//@{
// This comment is associated with the previous statement.
// @suffix
//@}
