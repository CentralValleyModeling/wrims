// Test extern processing.
extern "C" {
  /** f1 */
  void f1();
  /** f2 */
  void f2();
  void f3();
  /**
   * f3
   * @suffix
   */
  void f4();
  /**
   * f4
   * @suffix
   */
}
