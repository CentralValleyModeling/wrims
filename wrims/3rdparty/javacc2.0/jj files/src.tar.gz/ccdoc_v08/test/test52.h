// Verify the fix for issue 0118.
namespace test52
{
  class A
  {
  public:
    typedef int nested_type;
    class nested_class {};
    void fct();
  };
  
  class Test
  {
  public:
    /** Linked correctly */
    A get_some_class();
    /** Not linked correctly */
    A::nested_type  get_nested_type();
    /** Not linked correctly */
    A::nested_class get_nested_class();
    A::fct get_nested_fct();
  };
}
