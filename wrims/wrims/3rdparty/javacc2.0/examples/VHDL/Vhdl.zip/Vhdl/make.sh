#csh
jjtree vhdl.jjt
javacc vhdl.jj
javac *.java
