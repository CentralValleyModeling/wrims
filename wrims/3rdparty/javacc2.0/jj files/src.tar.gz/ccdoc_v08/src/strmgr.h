//@copyright_begin
// ================================================================
// Copyright Notice
// Copyright (C) 1998-2001 by Joe Linoff (www.joelinoff.com/ccdoc)
// 
// This software is distributed in the hope that it will be useful, but
// without WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// 
// Permission is granted to anyone to make or distribute altered copies
// of this software provided that the copyright notice and this
// permission notice are preserved, that the distributor grants the
// recipent permission for further distribution as permitted by this
// notice and that the origin of the software is represented correctly.
// 
// Comments and suggestions are always welcome.
// Please report bugs to http://www.joelinoff.com/ccdoc
// ================================================================
//@copyright_end

// MULTIPLE INCLUSION GUARD
#ifndef ccdoc_strmgr_h
#define ccdoc_strmgr_h

/**
 * This static variable allows the header version
 * to be queried at runtime.
 */
static char ccdoc_strmgr_h_rcsid[] = "$Id: strmgr.h,v 1.1.1.1 2001/08/20 20:59:12 Administrator Exp $";

#include "exceptions.h"
#include <map>
#include <string>

namespace ccdoc {
  /**
   * String manager. This function keeps track of all strings
   * used in the system so that there is only one physical
   * copy (with a reference count).
   * @author Joe Linoff
   * @version $Id: strmgr.h,v 1.1.1.1 2001/08/20 20:59:12 Administrator Exp $
   */
  class strmgr {
  public:
    typedef map<string,unsigned,less<string> > str_coll;
    typedef map<string,unsigned,less<string> >::iterator str_coll_itr;
    typedef map<unsigned,const string*,less<unsigned> > idx_coll;
    typedef map<unsigned,const string*,less<unsigned> >::iterator idx_coll_itr;
  public:
    /**
     * Constructor.
     */
    strmgr();
    /**
     * Destructor.
     */
    ~strmgr();
  private:
    /**
     * Private copy constructor.
     */
    strmgr(const strmgr&);
  public:
    /**
     * Get the reference to the single copy of the string.
     * @param v The value to make a reference copy of.
     * @returns A reference copy of the string.
     */
    const string& get(const string& v);
    /**
     * Get the index associated with a string.
     * This method is used to generate output records.
     * @param v The value to make a reference copy of.
     * @returns The idx associated with a string.
     */
    unsigned get_idx(const string v);
  public:
    /**
     * Get a string by it's id. This method is used when
     * reading persistent data.
     * @param id The string idx.
     * @returns The string.
     */
    const string& get_by_idx(unsigned idx);
  public:
    unsigned size() const {return m_strmap.size();}
    str_coll_itr begin() {return m_strmap.begin();}
    str_coll_itr end() {return m_strmap.end();}
  public:
    /**
     * Create the xref maps.
     */
    void gen_maps();
  private:
    str_coll m_strmap;
    idx_coll m_idxmap;
    bool m_mapped;
  };
};

#endif

