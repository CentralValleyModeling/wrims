// This file verifies ccdoc javadoc style comment parsing only.
/**c1 short description*/
int c1;
/** c2 short description */
int c2;
/**
 *c3 short description*/
int c3;
/**  
 * c4 short description
 */
int c4;
/**
 * c5 short description
 */
int c5;
/**
 * c6 short description
 *
 * c6 long description
 */
int c6;
/**c7 short description
 *
 * c7 long description
 */
int c7;
/** @returns c8
 * c8 long description
 */
int c8;
/**
 * c9 Check end processing.
 **/
int c9;
/** c10 Check end processing. **/
int c10;
/**
 * Check @@ processing.
 *@@ for(int i=0;i<10 && j>5;++i);
 */
int c11;
/**
 *@{
 * Check @{ and @} ignore warnings for multi-line comments.
 *@}
 */
int c12;
/**
 * c13 short description
 *
 * c13 long description
 * @author author c13 Foo Bar
 * @author author c13 Foo Spam
 * @version version c13
 */
int c13;
/**
 * @author author c14 Foo Bar
 * @version version c14
 * c14 not a  short description
 *
 * c14 long description
 */
int c14;
/**
 * Test the @link directive.
 * @link c14 c14
 * Is another comment.
 */
int c15;
/**/
int c16;
/***/
int c17;
/***/
int c18;
/**
 * This shows how @exception, @param and @returns can span multiple lines.
 * @param p1 This parameter can have a
 *@@         value < 10 and > 0. If the value
 *           is out of range, an exception is thrown.
 * @returns Return
 *@@ true if the value is < max or false if the value is >= max.
 * For more information about the value click
 *@link utils::value here
 *.
 *@see utils::foo::bar
 *@see utils::foo::spam 2
 * @exception Port::Exception Is thrown when the program
 * runs out of disk space.
 * @exception MyException Is thrown sometimes.
 * @author foo bar
 */
int c19;
/** @pkg A..B **/
int c20_error;
/** @pkg A.B.C **/
int c21;
/** @pkg A **/
int c22;
/**
 * Check @pkg and @pkgdoc conflicts.
 * @pkg A
 * @pkgdoc A
 */
int c23_error;
/**
 * Check multiply defined conflicts for @pkgdoc and @source.
 * @pkgdoc A 
 * @pkgdoc A 
 * @source foo.c
 * @source foo.c
 */
int c24_error;
/**
 * Check multiply defined conflicts for @pkg.
 * @pkg A 
 * @pkg A 
 */
int c25_error;
/**
 * Check the @deprecated and @$ directives, look at
 * @$ c32 c32 text
 * and
 * @$ c31
 * .
 * @deprecated
 *   Use the
 * @link c32
 * interface instead.
 * @returns Stuff.
 */
int c33;
