// Verify fix for issue 0116
namespace test50 {
  class Test
  {
  public:
    void Val(const char* = "\\");
  };
}
