// Issue 0064
namespace test028  {
  
  class some_class
  {
  public:
    int some_class();
  };
  
  class some_other_class
  {
    /** Red, but not linked */
    friend class some_class;
  public:
    int some_other_class();
    };
}
