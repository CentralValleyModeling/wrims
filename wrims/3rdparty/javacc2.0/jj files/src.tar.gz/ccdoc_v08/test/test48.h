// Verify fix for issue 0112
namespace test48 {
  int operator|(int,int);
}

