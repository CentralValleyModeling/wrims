public class VBErrHandlerVisitor extends VBParserVisit implements VBParserTreeConstants, VBParserConstants
{
	public static final int REPORT_ONLY				= 0x0001;
	public static final int REPLACE_EXISTING		= 0x0002;
	public static final int SILENT					= 0x0004;

	VBErrHandlerVisitor()
	{
		super();
	}

	VBErrHandlerVisitor(int options)
	{
		super();
		this.options = options;
	}

	private int options = 0;

	private int statementCount;

	public Object visit(ASTCompilationUnit node, Object data){ node.childrenAccept(this, data); return data; }

	public Object visit(ASTProcDeclaration node, Object data)
	{
		try
		{
			String procName = node.getName();

			statementCount = 0;
			node.childrenAccept(this, data);

			ASTOnError onErr = (ASTOnError)(node.findNode(JJTONERROR));

			if ((options & SILENT) == 0)
			{
				System.out.println("Proc \"" + procName + "\": " + statementCount + " " + (onErr == null ? "No Handler" : onErr.getGotoLabel().getName()));
			}

			// The label will normally be a a alphanumeric label, but could be a
			// line number. Therefore use SimpleNode, as it might return either
			// a ASTLabel or a ASTLiteral.
			//SimpleNode errHandler = null;

			if (onErr == null)
			{
				// No "On Error"

				if ((options & REPORT_ONLY) == 0)
				{
					addErrorHandler(node);
				}
			}
			else if (onErr.getGotoLabel() == null)
			{
				// Must have been "On Error Resume Next" etc.
			}
			else if (! (onErr.getGotoLabel() instanceof ASTName))
			{
				System.out.println("On Error Goto Line Nuumber not supported");
			}
			else
			{
				// On Error Goto Label

				ASTName label = (ASTName)onErr.getGotoLabel();

				ASTStatements statements = node.getStatements();

					//statements.insertChild(new ASTStatement(JJTSTATEMENT), -1, "BLAH!\n");
			}
		}
		catch(Exception e)
		{
			System.out.println("Error adding BLAH");
			System.out.println(e);
			e.printStackTrace();
		}

		return data;
	}

	// This version of "visit" is called for ASTStatement and all of its derived
	// classes (this is done by the VBParserVisit class).
	public Object visit(ASTStatement node, Object data)
	{
		System.out.println("Statement: " + node);
		statementCount++;
		node.childrenAccept(this, data);
		return data;
	}

	public Object visit(ASTLabel node, Object data)
	{
		System.out.println("Label " + node);
		node.childrenAccept(this, data);
		return data;
	}


	private void addErrorHandler(ASTProcDeclaration proc) throws ParseException
	{
		ASTStatements statements = proc.getStatements();

		statements.insertChild(new ASTStatement(JJTSTATEMENT), 0, "On Error Goto Handler\n");
		statements.insertChild(
				makeStatements(new String[] {
					"Exit Sub",			// TODO - or function...
					"Handler:",
					"      Dim ErrNumber as long: ErrNumber = Err.Number",
					"      Dim ErrSource as long: ErrNumber = Err.Source",
					"      Dim ErrDescription as long: ErrNumber = Err.Description"}),
				-1);
	}

	private ASTStatement[] makeStatements(String[] text)
	{
		ASTStatement[] statements = new ASTStatement[text.length];

		for (int i = 0; i < text.length; i++)
		{
			Token t = Token.newToken(IDENTIFIER);
			t.image = text[i] + "\n";
			t.next = null;
			t.specialToken = null;
			ASTStatement s = new ASTStatement(JJTSTATEMENT);
			s.begin = t;
			s.end = t;

			statements[i] = s;

			if (i > 0)
				statements[i - 1].end.next = t;
		}

		return statements;
	}
}
