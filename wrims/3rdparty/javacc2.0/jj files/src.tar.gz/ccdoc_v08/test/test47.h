// Verify fix for issues 103 and 104
namespace test47 {
  class Test
  {
  public:
    int operator~();
    int operator&();
  };
}

