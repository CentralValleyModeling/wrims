// This file verifies ccdoc C++ style comment parsing only.
//@{
//c1 short description
//@}
int c1;
///**
//c2 short description
//*/
int c2;
///**
// * c3 short description
// */
int c3;
///**
// * c4 short description1
// * c4 short description2
// *
// * c4 long description
// */
int c4;
// ================================================
//@{
// c5 short description1
// c5 short description2
//
// c5 long description
//@}
// ================================================
int c5;
///**c6 short description1
// * c6 short description2
// *
// * c6 long description
// */
int c6;
//@{c7 short description1
//  c7 short description2
//
// c7 long description
//@}
int c7;
// ================================================
//@{
// c8 short description
//
// c8 long description
// @author author c8 Foo Bar
// @author author c8 Foo Spam
// @version version c8
//@}
// ================================================
int c8;
// ================================================
//@{
// @author author c9 Foo Bar
// @version version c9
// c9 not a  short description
//
// c9 long description
//@}
// ================================================
int c9;
// ================================================
//@{
// This shows how @exception, @param and @returns can span multiple lines.
// @param p1 This parameter can have a
//@@         value < 10 and > 0. If the value
//           is out of range, an exception is thrown.
// @returns Return
//@@ true if the value is < max or false if the value is >= max.
// For more information about the value click
//@link utils::value here
//.
//@see utils::foo::bar
//@see utils::foo::spam 2
// @exception Port::Exception Is thrown when the program
// runs out of disk space.
// @exception MyException Is thrown sometimes.
// @author foo bar
//@}
// ================================================
int c20;
//@{ Check single line comments. //@}
int c21;
//@{
// Check the @deprecated and @$ directives, look at
// @$ c32 c32 text
// and
// @$ c31
// .
// @deprecated
//   Use the
// @link c32
// interface instead.
// @returns Stuff.
//@}
int c33;
