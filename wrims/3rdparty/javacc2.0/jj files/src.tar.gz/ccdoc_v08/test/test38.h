// Verify the fix for issue 0080.
class test38_A {
public:
  virtual void fct();
};
class test38_B : public test38_A {
public:
  /**
   * You should look at class
   * @link test38_A::fct  
   * for more details.
   */
  void fct();
};
