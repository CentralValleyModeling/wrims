/** Issue 0014. Zero-argument const method type for Node */
typedef Node* (Node:*NodeConstMeth) () const;
