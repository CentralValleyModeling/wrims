/* JJT: 0.3pre1 */


package UK.co.demon.almide.util.pretty;



public interface PrettyTreeConstants
{
  int JJTCOMPILATIONUNIT = 0;
  int JJTPACKAGE_OPTION = 1;
  int JJTIMPORT_SEQUENCEOPTION = 2;
  int JJTTYPEDEC_SEQUENCEOPTION = 3;
  int JJTPACKAGEDECLARATION = 4;
  int JJTIMPORTDECLARATION = 5;
  int JJTTYPEDECLARATION = 6;
  int JJTCLASSDECLARATION = 7;
  int JJTMODIFIERS = 8;
  int JJTUNMODIFIEDCLASSDECLARATION = 9;
  int JJTCLASSEXTENDS_OPTION = 10;
  int JJTCLASSIMPLEMENTS_OPTION = 11;
  int JJTCLASSBODY = 12;
  int JJTCLASSBODYDECS_SEQUENCEOPTION = 13;
  int JJTNESTEDCLASSDECLARATION = 14;
  int JJTCLASSBODYDECLARATION = 15;
  int JJTVOID = 16;
  int JJTINTERFACEDECLARATION = 17;
  int JJTNESTEDINTERFACEDECLARATION = 18;
  int JJTUNMODIFIEDINTERFACEDECLARATION = 19;
  int JJTINTERFACEEXTENDS_OPTION = 20;
  int JJTINTERFACEBODY = 21;
  int JJTINTERFACEBODYDECS_SEQUENCEOPTION = 22;
  int JJTINTERFACEMEMBERDECLARATION = 23;
  int JJTFIELD_DECS = 24;
  int JJTFIELDDECLARATION = 25;
  int JJTNODE = 26;
  int JJTVARIABLEDECLARATOR = 27;
  int JJTVARIABLEINITIALIZATION_OPTION = 28;
  int JJTVARIABLEDECLARATORID = 29;
  int JJTVARIABLEINITIALIZER = 30;
  int JJTARRAYINITIALIZER = 31;
  int JJTARRAYINIT_SEQUENCEOPTION = 32;
  int JJTARRAYINIT_OPTION = 33;
  int JJTMETHODDECLARATION = 34;
  int JJTUNMODIFIEDMETHODDECLARATION = 35;
  int JJTTHROWS_OPTION = 36;
  int JJTMETHODBODY = 37;
  int JJTMETHODDECLARATOR = 38;
  int JJTFORMALPARAMETERS = 39;
  int JJTFORMALPARAMETER = 40;
  int JJTCONSTRUCTORDECLARATION = 41;
  int JJTUNMODIFIEDCONSTRUCTORDECLARATION = 42;
  int JJTCONSTRUCTORBODY = 43;
  int JJTEXPLICITCONSTRUCTOR_OPTION = 44;
  int JJTBLOCKSTATEMENT_SEQUENCEOPTION = 45;
  int JJTEXPLICITCONSTRUCTORINVOCATION = 46;
  int JJTINITIALIZER = 47;
  int JJTTYPE = 48;
  int JJTPRIMITIVETYPE = 49;
  int JJTRESULTTYPE = 50;
  int JJTNAME = 51;
  int JJTNAMELIST = 52;
  int JJTEXPRESSION = 53;
  int JJTASSIGNMENTOPERATOR = 54;
  int JJTCONDITIONALEXPRESSION = 55;
  int JJTHOOK_OP = 56;
  int JJTCONDITIONALOREXPRESSION = 57;
  int JJTSPACED_OP = 58;
  int JJTCONDITIONALANDEXPRESSION = 59;
  int JJTINCLUSIVEOREXPRESSION = 60;
  int JJTEXCLUSIVEOREXPRESSION = 61;
  int JJTANDEXPRESSION = 62;
  int JJTEQUALITYEXPRESSION = 63;
  int JJTINSTANCEOFEXPRESSION = 64;
  int JJTRELATIONALEXPRESSION = 65;
  int JJTSHIFTEXPRESSION = 66;
  int JJTADDITIVEEXPRESSION = 67;
  int JJTMULTIPLICATIVEEXPRESSION = 68;
  int JJTUNARYEXPRESSION = 69;
  int JJTPREINCREMENTEXPRESSION = 70;
  int JJTPREDECREMENTEXPRESSION = 71;
  int JJTUNARYEXPRESSIONNOTPLUSMINUS = 72;
  int JJTPOSTFIXEXPRESSION = 73;
  int JJTCASTEXPRESSION = 74;
  int JJTPRIMARYEXPRESSION = 75;
  int JJTPRIMARYPREFIX = 76;
  int JJTPRIMARYSUFFIX = 77;
  int JJTARGUMENTS = 78;
  int JJTARGUMENTLIST = 79;
  int JJTALLOCATIONEXPRESSION = 80;
  int JJTALLOC_CLASS = 81;
  int JJTARRAYDIMENSIONS = 82;
  int JJTLABELEDSTATEMENT = 83;
  int JJTLABELS = 84;
  int JJTLABEL = 85;
  int JJTBLOCK = 86;
  int JJTLOCALVAR_STATEMENT = 87;
  int JJTLOCALVARIABLEDECLARATION = 88;
  int JJTEMPTYSTATEMENT = 89;
  int JJTSTATEMENTEXPRESSION = 90;
  int JJTSWITCHSTATEMENT = 91;
  int JJTSWITCHBODY = 92;
  int JJTCASE_NODE = 93;
  int JJTCASE_SEQUENCEOPTION = 94;
  int JJTSWITCHLABEL = 95;
  int JJTCASE_LABEL = 96;
  int JJTIFSTATEMENT = 97;
  int JJTELSE_OPTION = 98;
  int JJTWHILESTATEMENT = 99;
  int JJTDOSTATEMENT = 100;
  int JJTFORSTATEMENT = 101;
  int JJTFORCONTROL_NODE = 102;
  int JJTFORINIT = 103;
  int JJTSTATEMENTEXPRESSIONLIST = 104;
  int JJTFORUPDATE = 105;
  int JJTBREAKSTATEMENT = 106;
  int JJTCONTINUESTATEMENT = 107;
  int JJTRETURNSTATEMENT = 108;
  int JJTTHROWSTATEMENT = 109;
  int JJTSYNCHRONIZEDSTATEMENT = 110;
  int JJTTRYSTATEMENT = 111;
  int JJTCATCH_NODE = 112;
  int JJTFINALLY_NODE = 113;
  int JJTTOKEN = 114;
  int JJTKEYWORD = 115;


  String[] jjtNodeName = {
    "CompilationUnit",
    "Package_OPTION",
    "Import_SEQUENCEOPTION",
    "TypeDec_SEQUENCEOPTION",
    "PackageDeclaration",
    "ImportDeclaration",
    "TypeDeclaration",
    "ClassDeclaration",
    "MODIFIERS",
    "UnmodifiedClassDeclaration",
    "ClassExtends_OPTION",
    "ClassImplements_OPTION",
    "ClassBody",
    "ClassBodyDecs_SEQUENCEOPTION",
    "NestedClassDeclaration",
    "ClassBodyDeclaration",
    "void",
    "InterfaceDeclaration",
    "NestedInterfaceDeclaration",
    "UnmodifiedInterfaceDeclaration",
    "InterfaceExtends_OPTION",
    "InterfaceBody",
    "InterfaceBodyDecs_SEQUENCEOPTION",
    "InterfaceMemberDeclaration",
    "Field_DECS",
    "FieldDeclaration",
    "NODE",
    "VariableDeclarator",
    "VariableInitialization_OPTION",
    "VariableDeclaratorId",
    "VariableInitializer",
    "ArrayInitializer",
    "ArrayInit_SEQUENCEOPTION",
    "ArrayInit_OPTION",
    "MethodDeclaration",
    "UnmodifiedMethodDeclaration",
    "Throws_OPTION",
    "MethodBody",
    "MethodDeclarator",
    "FormalParameters",
    "FormalParameter",
    "ConstructorDeclaration",
    "UnmodifiedConstructorDeclaration",
    "ConstructorBody",
    "ExplicitConstructor_OPTION",
    "BlockStatement_SEQUENCEOPTION",
    "ExplicitConstructorInvocation",
    "Initializer",
    "Type",
    "PrimitiveType",
    "ResultType",
    "Name",
    "NameList",
    "Expression",
    "AssignmentOperator",
    "ConditionalExpression",
    "Hook_OP",
    "ConditionalOrExpression",
    "SPACED_OP",
    "ConditionalAndExpression",
    "InclusiveOrExpression",
    "ExclusiveOrExpression",
    "AndExpression",
    "EqualityExpression",
    "InstanceOfExpression",
    "RelationalExpression",
    "ShiftExpression",
    "AdditiveExpression",
    "MultiplicativeExpression",
    "UnaryExpression",
    "PreIncrementExpression",
    "PreDecrementExpression",
    "UnaryExpressionNotPlusMinus",
    "PostfixExpression",
    "CastExpression",
    "PrimaryExpression",
    "PrimaryPrefix",
    "PrimarySuffix",
    "Arguments",
    "ArgumentList",
    "AllocationExpression",
    "Alloc_CLASS",
    "ArrayDimensions",
    "LabeledStatement",
    "Labels",
    "Label",
    "Block",
    "LocalVar_STATEMENT",
    "LocalVariableDeclaration",
    "EmptyStatement",
    "StatementExpression",
    "SwitchStatement",
    "SwitchBody",
    "Case_NODE",
    "Case_SEQUENCEOPTION",
    "SwitchLabel",
    "Case_LABEL",
    "IfStatement",
    "Else_OPTION",
    "WhileStatement",
    "DoStatement",
    "ForStatement",
    "ForControl_NODE",
    "ForInit",
    "StatementExpressionList",
    "ForUpdate",
    "BreakStatement",
    "ContinueStatement",
    "ReturnStatement",
    "ThrowStatement",
    "SynchronizedStatement",
    "TryStatement",
    "Catch_NODE",
    "Finally_NODE",
    "Token",
    "Keyword",
  };
}
