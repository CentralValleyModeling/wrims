// Verify fix for issue 78
const long test36 = (1+1);
