$prog -log help.log -h
$prog -warn
$prog -nowarn
$prog -v
$prog -nov
