// Issue 0069
int operator/(const int&){}
