// Verify the fix for issue 0073.
class test30 {
private:
  /** This should NOT be reported! */
  test30();
};
