// Verify issue 0025
/**
 * @pkgdoc A/B ../doc/index.html
 */
/** @pkgdoc A/B/C ../doc/index.html*/
