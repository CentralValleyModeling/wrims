// Test for issue 43.
class test19 {
public:
  class test19_inner {
  };
  void fct1();
  void fct2();
  void fct3();
  void fct4();
  /**
   * Test function.
   * @see #fct1
   * @see #fct2
   * @see #fct3
   * @see #fct4
   * @see #test19_inner
   */
  void test();
};

