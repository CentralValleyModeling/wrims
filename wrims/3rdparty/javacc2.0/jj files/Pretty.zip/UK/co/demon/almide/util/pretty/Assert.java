package UK.co.demon.almide.util.pretty;


/**
* A simple assertion mechanism for asserting validity of
* arguments.
*
* <p>
* @version                     1.0 Tue 10-Jun-97
* @author                      Sandy Anderson
* <p>
* Last change:  ALM  29 Jul 97   10:25 pm
**/

public class
Assert {

    static public void
    notFalse (boolean condition) throws RuntimeException {
        if (! condition)  throw new RuntimeException("BAD ASSERTION: false condition!");
    }// notFalse(boolean)



    static public void
    notFalse (boolean condition, String message) throws RuntimeException {
        if (! condition)  throw new RuntimeException(message);
    }// notFalse(boolean,String)



    static public void
    notNull (Object object) throws RuntimeException {
        if (object == null)  throw new RuntimeException("BAD ASSERTION: null reference!");
    }// notNull(Object)



    static public void
    notNull (Object object, String message) throws RuntimeException {
        if (object == null)  throw new RuntimeException(message);
    }// notNull(Object,String)

}// Assert




/*  Correct my address in any reply, or it'll be treated as spam: 
--                                                          
//     Alexander Anderson    <DELETE_THIS.sandy@almide.demon.co.uk>
//     Home Fone                               +44 (0) 171-794-4543
//     London, UK                    http://www.almide.demon.co.uk/ 
//     PGP print   C6 8C 55 F2 77 7B 99 9B  14 77 66 F5 B8 74 CF 12
*/
