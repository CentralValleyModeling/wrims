// Test for issue 45.
class test21 {
public:
  /**
   * Test the code section (-rptfwcf).
   */
  static long long test(int p1,const char* p2=5,const string& p3);
};
