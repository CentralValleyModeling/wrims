// Verify the fix for issue 0075
class test35 {
public:
  char m_foo[BAR];
};
